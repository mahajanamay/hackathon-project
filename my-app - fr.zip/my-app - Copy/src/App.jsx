import { useState, useEffect } from "react";

// ─── Design Tokens — LIGHT THEME ─────────────────────────────────────────────
const C = {
  // Backgrounds
  bgRoot:     "#f6f3ed",   // warm off-white
  bgMain:     "#ffffff",   // slightly lighter
  sidebar:    "#7b441a",   // dark green sidebar
  sidebarAlt: "#243222",
  card:       "#ffffff",
  cardBorder: "#e2ddd4",
  cardAlt:    "#f7f5f0",

  // Borders
  border:     "#ddd8cc",
  borderSoft: "#eae6de",

  // Browns
  brown:      "#7a5c2e",
  brownMid:   "#9a7440",
  brownLight: "#b89060",
  brownPale:  "#e8d8b8",

  // Silvers / Greys
  silver:     "#6b7a84",
  silverMid:  "#8a9aa4",
  silverLight:"#b0bec8",
  silverPale: "#dce6ec",

  // Greens
  green:      "#2e5e3e",
  greenMid:   "#3d7a50",
  greenLight: "#5a9e6a",
  greenPale:  "#c8e8d0",
  greenBg:    "#eef6f0",

  // Blues
  blue:       "#1e5f74",
  blueMid:    "#2e7d9a",
  blueLight:  "#4a9ab8",
  bluePale:   "#cce4ee",
  blueBg:     "#edf5f9",

  // Status
  critical:   "#c0392b",
  criticalBg: "#fdf0ee",
  criticalBorder:"#f5c0bb",
  high:       "#b05a0a",
  highBg:     "#fdf4ec",
  moderate:   "#8a7a10",
  moderateBg: "#fdfaec",
  normal:     "#2e6e40",
  normalBg:   "#eef6f1",

  // Text
  textH:      "#1a2420",   // near black
  textBody:   "#3a4840",   // dark green-grey
  textMuted:  "#6a7870",   // muted
  textDim:    "#9aaa a0",  // very dim
  textLight:  "#b0beb8",
};

const F = {
  heading: "'Inter', 'Segoe UI', system-ui, sans-serif",
  body:    "'Inter', 'Segoe UI', system-ui, sans-serif",
  mono:    "'Roboto Mono', 'Courier New', monospace",
};

// ─── Data ─────────────────────────────────────────────────────────────────────
const VILLAGES = [
  { id:1, name:"Marathwada North", district:"Aurangabad", population:12400, lat:19.88, lng:75.34, rainfall:22,  groundwater:15, tankerAssigned:3 },
  { id:2, name:"Solapur Rural",    district:"Solapur",    population:8900,  lat:17.68, lng:75.90, rainfall:55,  groundwater:38, tankerAssigned:1 },
  { id:3, name:"Latur East",       district:"Latur",      population:15200, lat:18.40, lng:76.56, rainfall:18,  groundwater:12, tankerAssigned:5 },
  { id:4, name:"Osmanabad Block",  district:"Osmanabad",  population:6700,  lat:18.18, lng:76.04, rainfall:72,  groundwater:55, tankerAssigned:0 },
  { id:5, name:"Nanded West",      district:"Nanded",     population:11300, lat:19.15, lng:77.31, rainfall:45,  groundwater:30, tankerAssigned:2 },
  { id:6, name:"Beed Central",     district:"Beed",       population:9800,  lat:18.99, lng:75.76, rainfall:28,  groundwater:20, tankerAssigned:4 },
  { id:7, name:"Jalna Taluka",     district:"Jalna",      population:7200,  lat:19.84, lng:75.88, rainfall:85,  groundwater:68, tankerAssigned:0 },
  { id:8, name:"Hingoli Block",    district:"Hingoli",    population:5400,  lat:19.72, lng:77.15, rainfall:62,  groundwater:44, tankerAssigned:1 },
];
const TANKERS = [
  { id:"T-001", capacity:10000, status:"deployed",    location:"Marathwada North", driver:"Rajan More"     },
  { id:"T-002", capacity:8000,  status:"deployed",    location:"Latur East",       driver:"Suresh Patil"   },
  { id:"T-003", capacity:12000, status:"available",   location:"Depot A",          driver:"Manoj Kale"     },
  { id:"T-004", capacity:10000, status:"deployed",    location:"Beed Central",     driver:"Dinesh Jadhav"  },
  { id:"T-005", capacity:8000,  status:"maintenance", location:"Garage B",         driver:"Anil Shinde"    },
  { id:"T-006", capacity:15000, status:"available",   location:"Depot A",          driver:"Vijay Gaikwad"  },
  { id:"T-007", capacity:10000, status:"deployed",    location:"Nanded West",      driver:"Pramod Desai"   },
  { id:"T-008", capacity:8000,  status:"deployed",    location:"Solapur Rural",    driver:"Sachin Bhosale" },
];
const ALERTS = [
  { id:1, type:"critical", village:"Latur East",       message:"Groundwater below 12m — immediate tanker dispatch required", time:"10 mins ago" },
  { id:2, type:"critical", village:"Marathwada North", message:"Rainfall 78% below seasonal average",                        time:"25 mins ago" },
  { id:3, type:"high",     village:"Beed Central",     message:"Water Stress Index elevated to HIGH",                        time:"1 hr ago"    },
  { id:4, type:"high",     village:"Nanded West",      message:"Groundwater declining — monitor closely",                    time:"2 hrs ago"   },
  { id:5, type:"moderate", village:"Solapur Rural",    message:"Rainfall deficit of 45% this week",                         time:"3 hrs ago"   },
  { id:6, type:"moderate", village:"Hingoli Block",    message:"Seasonal rainfall 38% below average",                       time:"4 hrs ago"   },
  { id:7, type:"normal",   village:"Jalna Taluka",     message:"Groundwater stable — no action needed",                     time:"5 hrs ago"   },
  { id:8, type:"high",     village:"Osmanabad Block",  message:"Groundwater dropped 8m this month",                         time:"6 hrs ago"   },
];

// ─── Logic ────────────────────────────────────────────────────────────────────
const getStressLevel = (r, g) => {
  if (r < 30 && g < 20) return "CRITICAL";
  if (r < 60 && g < 40) return "HIGH";
  if (r < 80)           return "MODERATE";
  return "NORMAL";
};
const getStressColor = l => ({
  CRITICAL: C.critical, HIGH: C.high, MODERATE: C.moderate, NORMAL: C.normal
}[l] || C.normal);
const getStressBg = l => ({
  CRITICAL: C.criticalBg, HIGH: C.highBg, MODERATE: C.moderateBg, NORMAL: C.normalBg
}[l] || C.normalBg);
const getStressBorder = l => ({
  CRITICAL: C.criticalBorder, HIGH:"#f5d0a0", MODERATE:"#e8dca0", NORMAL:"#a8d8b4"
}[l] || "#a8d8b4");
const getScore = (r, g) => Math.round((Math.max(0,100-r)*0.5)+(Math.max(0,100-g)*0.5));
const priorityRank = (villages, n) =>
  [...villages]
    .map(v=>({...v, stress:getStressLevel(v.rainfall,v.groundwater), score:getScore(v.rainfall,v.groundwater)}))
    .sort((a,b)=>(b.score+b.population*0.001)-(a.score+a.population*0.001))
    .slice(0,n);

// ─── Animated Counter ─────────────────────────────────────────────────────────
function AnimCounter({ target, duration=1000 }) {
  const [val, setVal] = useState(0);
  useEffect(() => {
    let start = 0;
    const step = target / (duration / 16);
    const timer = setInterval(() => {
      start += step;
      if (start >= target) { setVal(target); clearInterval(timer); }
      else setVal(Math.floor(start));
    }, 16);
    return () => clearInterval(timer);
  }, [target]);
  return <span>{val}</span>;
}

// ─── Shared Components ────────────────────────────────────────────────────────
const Badge = ({ level }) => {
  const col = getStressColor(level);
  const bg  = getStressBg(level);
  const bdr = getStressBorder(level);
  return (
    <span style={{
      background: bg, color: col, border: `1px solid ${bdr}`,
      borderRadius: 4, padding: "3px 10px",
      fontSize: 11, fontWeight: 600, fontFamily: F.body,
      letterSpacing: "0.04em",
    }}>{level}</span>
  );
};

const StatCard = ({ label, value, sub, accent, icon, delay=0 }) => (
  <div style={{
    background: C.card,
    border: `1px solid ${C.border}`,
    borderRadius: 10,
    padding: "20px 22px",
    flex: 1, minWidth: 130,
    borderTop: `3px solid ${accent || C.brownMid}`,
    boxShadow: "0 1px 4px rgba(0,0,0,0.06)",
    animation: `fadeSlideUp 0.5s ease ${delay}s both`,
  }}>
    <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:10 }}>
      <span style={{ fontFamily:F.body, color:C.textMuted, fontSize:11, fontWeight:500,
        letterSpacing:"0.04em", textTransform:"uppercase" }}>{label}</span>
      {icon && <span style={{ fontSize:16, opacity:0.35 }}>{icon}</span>}
    </div>
    <div style={{ fontFamily:F.heading, color: accent||C.brownMid, fontSize:36,
      fontWeight:700, lineHeight:1, marginBottom:6 }}>
      <AnimCounter target={typeof value==='number'?value:parseInt(value)||0}/>
      {typeof value==='string' && value.includes('mm') ? 'mm' : ''}
      {typeof value==='string' && value.includes('m') && !value.includes('mm') ? 'm' : ''}
    </div>
    {sub && <div style={{ fontFamily:F.body, color:C.textLight, fontSize:12 }}>{sub}</div>}
  </div>
);

const Card = ({ children, style={} }) => (
  <div style={{
    background: C.card,
    border: `1px solid ${C.border}`,
    borderRadius: 10,
    overflow: "hidden",
    boxShadow: "0 1px 4px rgba(0,0,0,0.06)",
    ...style,
  }}>{children}</div>
);

const CardHead = ({ left, right }) => (
  <div style={{
    padding: "14px 20px",
    borderBottom: `1px solid ${C.borderSoft}`,
    display: "flex", justifyContent: "space-between", alignItems: "center",
    background: C.cardAlt,
  }}>
    <div>{left}</div>
    {right && <div style={{ fontFamily:F.body, color:C.textLight, fontSize:11 }}>{right}</div>}
  </div>
);

const PageTitle = ({ title, sub }) => (
  <div style={{ marginBottom: 28 }}>
    <h1 style={{ fontFamily:F.heading, fontSize:26, fontWeight:700,
      color:C.textH, margin:0, letterSpacing:"-0.02em" }}>{title}</h1>
    {sub && <p style={{ fontFamily:F.body, color:C.textMuted, fontSize:13,
      margin:"5px 0 0" }}>{sub}</p>}
  </div>
);

const TH = ({ children }) => (
  <th style={{
    padding: "10px 16px", textAlign:"left",
    fontFamily: F.body, color: C.textMuted,
    fontSize: 11, fontWeight: 600,
    letterSpacing: "0.05em", textTransform:"uppercase",
    whiteSpace: "nowrap", background: C.cardAlt,
    borderBottom: `1px solid ${C.border}`,
  }}>{children}</th>
);

const FilterBtn = ({ active, color, onClick, children }) => (
  <button onClick={onClick} style={{
    padding: "6px 16px", borderRadius: 6,
    border: `1px solid ${active ? color : C.border}`,
    background: active ? color+"14" : C.card,
    color: active ? color : C.textMuted,
    cursor: "pointer", fontSize: 12,
    fontWeight: active ? 600 : 400,
    fontFamily: F.body,
    boxShadow: "0 1px 3px rgba(0,0,0,0.05)",
    transition: "all 0.15s",
  }}>{children}</button>
);

// ═══════════════════════════════════════════════════════════════════════════════
//  PAGES
// ═══════════════════════════════════════════════════════════════════════════════

function DashboardPage() {
  const vx = VILLAGES.map(v=>({...v, stress:getStressLevel(v.rainfall,v.groundwater), score:getScore(v.rainfall,v.groundwater)}));
  const critical = vx.filter(v=>v.stress==="CRITICAL").length;
  const high     = vx.filter(v=>v.stress==="HIGH").length;
  const deployed = TANKERS.filter(t=>t.status==="deployed").length;
  const avail    = TANKERS.filter(t=>t.status==="available").length;

  return (
    <div style={{ animation:"fadeIn 0.4s ease" }}>
      <PageTitle title="District Overview"
        sub="Real-time drought stress monitoring & tanker allocation status" />

      <div style={{ display:"flex", gap:14, marginBottom:26, flexWrap:"wrap" }}>
        <StatCard label="Critical Villages"  value={critical}  sub="Immediate action needed"        accent={C.critical}  icon="⚠"  delay={0.0}/>
        <StatCard label="High Stress"        value={high}      sub="Monitor closely"                accent={C.high}      icon="↑"  delay={0.1}/>
        <StatCard label="Tankers Deployed"   value={deployed}  sub={`of ${TANKERS.length} total`}   accent={C.greenMid}  icon="🚚" delay={0.2}/>
        <StatCard label="Available Tankers"  value={avail}     sub="Ready for dispatch"             accent={C.blueMid}   icon="◎"  delay={0.3}/>
      </div>

      {/* Village table */}
      <Card style={{ marginBottom:22 }}>
        <CardHead
          left={<span style={{ fontFamily:F.heading, fontWeight:600, color:C.textH, fontSize:14 }}>Village Stress Index</span>}
          right={`${VILLAGES.length} locations monitored`}
        />
        <div style={{ overflowX:"auto" }}>
          <table style={{ width:"100%", borderCollapse:"collapse" }}>
            <thead>
              <tr>{["Village","District","Population","Rainfall mm","Groundwater m","Stress Score","Status","Tankers"].map(h=><TH key={h}>{h}</TH>)}</tr>
            </thead>
            <tbody>
              {vx.sort((a,b)=>b.score-a.score).map((v,i)=>(
                <tr key={v.id} style={{ borderBottom:`1px solid ${C.borderSoft}`,
                  background: i%2===0 ? C.card : C.cardAlt,
                  transition:"background 0.15s" }}>
                  <td style={{ padding:"12px 16px", fontFamily:F.body, color:C.textH, fontWeight:600, fontSize:13 }}>{v.name}</td>
                  <td style={{ padding:"12px 16px", fontFamily:F.body, color:C.textMuted, fontSize:13 }}>{v.district}</td>
                  <td style={{ padding:"12px 16px", fontFamily:F.mono, color:C.textBody, fontSize:12 }}>{v.population.toLocaleString()}</td>
                  <td style={{ padding:"12px 16px", fontFamily:F.mono, color:C.textBody, fontSize:12 }}>{v.rainfall}</td>
                  <td style={{ padding:"12px 16px", fontFamily:F.mono, color:C.textBody, fontSize:12 }}>{v.groundwater}</td>
                  <td style={{ padding:"12px 16px" }}>
                    <div style={{ display:"flex", alignItems:"center", gap:9 }}>
                      <div style={{ width:72, height:5, background:C.borderSoft, borderRadius:3, overflow:"hidden" }}>
                        <div style={{ width:`${v.score}%`, height:"100%",
                          background:getStressColor(v.stress), borderRadius:3 }}/>
                      </div>
                      <span style={{ fontFamily:F.mono, color:C.textMuted, fontSize:11 }}>{v.score}</span>
                    </div>
                  </td>
                  <td style={{ padding:"12px 16px" }}><Badge level={v.stress}/></td>
                  <td style={{ padding:"12px 16px", fontFamily:F.mono, color:C.blueMid, fontSize:13, fontWeight:600 }}>{v.tankerAssigned}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Alerts */}
      <Card style={{ border:`1px solid ${C.criticalBorder}` }}>
        <CardHead
          left={
            <div style={{ display:"flex", alignItems:"center", gap:9 }}>
              <div style={{ width:7, height:7, borderRadius:"50%", background:C.critical, animation:"blink 1.5s infinite" }}/>
              <span style={{ fontFamily:F.heading, fontWeight:600, color:C.critical, fontSize:14 }}>Live Alerts</span>
            </div>
          }
          right="Auto-refreshing"
        />
        {ALERTS.slice(0,4).map(a=>{
          const col = getStressColor(a.type.toUpperCase());
          return (
            <div key={a.id} style={{ display:"flex", alignItems:"center", gap:14,
              padding:"12px 20px", borderBottom:`1px solid ${C.borderSoft}` }}>
              <div style={{ width:6, height:6, borderRadius:"50%", background:col, flexShrink:0 }}/>
              <span style={{ fontFamily:F.body, color:C.textBody, fontSize:13, flex:1 }}>
                <strong style={{ color:C.textH }}>{a.village}</strong> — {a.message}
              </span>
              <span style={{ fontFamily:F.body, color:C.textLight, fontSize:11, whiteSpace:"nowrap" }}>{a.time}</span>
            </div>
          );
        })}
      </Card>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
function MapPage() {
  const vx = VILLAGES.map(v=>({...v, stress:getStressLevel(v.rainfall,v.groundwater), score:getScore(v.rainfall,v.groundwater)}));
  const [sel, setSel] = useState(null);
  const toX = lng=>((lng-74)/(78-74))*620;
  const toY = lat=>(1-(lat-17)/(21-17))*380;

  return (
    <div style={{ animation:"fadeIn 0.4s ease" }}>
      <PageTitle title="Stress Map" sub="Village-level water stress visualisation — Maharashtra region" />

      <div style={{ display:"flex", gap:18, marginBottom:18, flexWrap:"wrap" }}>
        {["CRITICAL","HIGH","MODERATE","NORMAL"].map(l=>(
          <div key={l} style={{ display:"flex", alignItems:"center", gap:7 }}>
            <div style={{ width:9, height:9, borderRadius:"50%", background:getStressColor(l) }}/>
            <span style={{ fontFamily:F.body, color:C.textMuted, fontSize:12 }}>{l}</span>
          </div>
        ))}
      </div>

      <div style={{ display:"flex", gap:18, flexWrap:"wrap" }}>
        <Card style={{ flex:2, minWidth:300, padding:20 }}>
          <svg viewBox="0 0 660 420" style={{ width:"100%", height:"auto" }}>
            <rect width="660" height="420" fill={C.bgRoot} rx="4"/>
            {[...Array(8)].map((_,i)=><line key={`v${i}`} x1={i*85} y1={0} x2={i*85} y2={420} stroke={C.border} strokeWidth={0.8}/>)}
            {[...Array(6)].map((_,i)=><line key={`h${i}`} x1={0} y1={i*72} x2={660} y2={i*72} stroke={C.border} strokeWidth={0.8}/>)}
            {vx.map(v=>{
              const x=toX(v.lng), y=toY(v.lat), col=getStressColor(v.stress), bg=getStressBg(v.stress);
              const isSel=sel?.id===v.id;
              return (
                <g key={v.id} onClick={()=>setSel(isSel?null:v)} style={{ cursor:"pointer" }}>
                  {v.stress==="CRITICAL"&&(
                    <circle cx={x} cy={y} r={22} fill="none" stroke={col} strokeWidth={1} strokeOpacity={0.25}>
                      <animate attributeName="r" from="13" to="26" dur="2s" repeatCount="indefinite"/>
                      <animate attributeName="stroke-opacity" from="0.4" to="0" dur="2s" repeatCount="indefinite"/>
                    </circle>
                  )}
                  <circle cx={x} cy={y} r={isSel?16:12} fill={bg} stroke={col} strokeWidth={isSel?2.5:1.5}/>
                  <text x={x} y={y+4} textAnchor="middle" fontSize={8} fill={col}
                    fontWeight={700} fontFamily="Roboto Mono, Courier New, monospace">{v.score}</text>
                  <text x={x} y={y+24} textAnchor="middle" fontSize={9} fill={C.textMuted}
                    fontFamily="Inter, sans-serif">{v.name.split(" ")[0]}</text>
                </g>
              );
            })}
          </svg>
          <div style={{ textAlign:"center", fontFamily:F.body, color:C.textLight,
            fontSize:11, marginTop:8 }}>
            Schematic layout — connect Google Maps API for live coordinates
          </div>
        </Card>

        <div style={{ flex:1, minWidth:210, display:"flex", flexDirection:"column", gap:12 }}>
          {sel ? (
            <Card style={{ border:`1px solid ${getStressBorder(sel.stress)}`, padding:20 }}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:16 }}>
                <div>
                  <div style={{ fontFamily:F.heading, color:C.textH, fontWeight:700, fontSize:17 }}>{sel.name}</div>
                  <div style={{ fontFamily:F.body, color:C.textMuted, fontSize:12, marginTop:2 }}>{sel.district}</div>
                </div>
                <Badge level={sel.stress}/>
              </div>
              {[["Population",sel.population.toLocaleString()],["Rainfall",`${sel.rainfall} mm`],
                ["Groundwater",`${sel.groundwater} m`],["Stress Score",getScore(sel.rainfall,sel.groundwater)],
                ["Tankers Assigned",sel.tankerAssigned]].map(([k,v])=>(
                <div key={k} style={{ display:"flex", justifyContent:"space-between",
                  padding:"8px 0", borderBottom:`1px solid ${C.borderSoft}` }}>
                  <span style={{ fontFamily:F.body, color:C.textMuted, fontSize:12 }}>{k}</span>
                  <span style={{ fontFamily:F.mono, color:C.textH, fontSize:12, fontWeight:500 }}>{v}</span>
                </div>
              ))}
            </Card>
          ):(
            <Card style={{ padding:24, textAlign:"center" }}>
              <div style={{ fontFamily:F.body, color:C.textLight, fontSize:13 }}>Click a village node</div>
              <div style={{ fontFamily:F.body, color:C.textLight, fontSize:11, marginTop:4 }}>to view details</div>
            </Card>
          )}
          {["CRITICAL","HIGH","MODERATE","NORMAL"].map(level=>{
            const count=vx.filter(v=>v.stress===level).length;
            const col=getStressColor(level);
            const bg=getStressBg(level);
            return (
              <div key={level} style={{ background:bg,
                border:`1px solid ${getStressBorder(level)}`,
                borderLeft:`3px solid ${col}`, borderRadius:8,
                padding:"10px 14px", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                <span style={{ fontFamily:F.body, color:C.textBody, fontSize:12, fontWeight:500 }}>{level}</span>
                <span style={{ fontFamily:F.mono, color:col, fontWeight:700, fontSize:14 }}>{count}</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
function TankersPage() {
  const [filter, setFilter] = useState("all");
  const filtered = filter==="all" ? TANKERS : TANKERS.filter(t=>t.status===filter);
  const statusCol  = { deployed:C.blueMid, available:C.greenMid, maintenance:C.high };
  const statusBg   = { deployed:C.blueBg,  available:C.greenBg,  maintenance:C.highBg };

  return (
    <div style={{ animation:"fadeIn 0.4s ease" }}>
      <PageTitle title="Tanker Fleet" sub="Monitor and manage all water tanker deployments" />

      <div style={{ display:"flex", gap:14, marginBottom:24, flexWrap:"wrap" }}>
        {[
          { label:"Total Fleet",  val:TANKERS.length,                                       color:C.brownMid  },
          { label:"Deployed",     val:TANKERS.filter(t=>t.status==="deployed").length,   color:C.blueMid   },
          { label:"Available",    val:TANKERS.filter(t=>t.status==="available").length,  color:C.greenMid  },
          { label:"Maintenance",  val:TANKERS.filter(t=>t.status==="maintenance").length,color:C.high      },
        ].map((s,i)=>(
          <div key={s.label} style={{ background:C.card, border:`1px solid ${C.border}`,
            borderTop:`3px solid ${s.color}`, borderRadius:10,
            padding:"18px 22px", flex:1, minWidth:110,
            boxShadow:"0 1px 4px rgba(0,0,0,0.05)",
            animation:`fadeSlideUp 0.4s ease ${i*0.08}s both` }}>
            <div style={{ fontFamily:F.body, color:C.textMuted, fontSize:11, fontWeight:500,
              textTransform:"uppercase", letterSpacing:"0.05em", marginBottom:8 }}>{s.label}</div>
            <div style={{ fontFamily:F.heading, color:s.color, fontSize:32, fontWeight:700 }}>
              <AnimCounter target={s.val}/>
            </div>
          </div>
        ))}
      </div>

      <div style={{ display:"flex", gap:8, marginBottom:20, flexWrap:"wrap" }}>
        {["all","deployed","available","maintenance"].map(s=>(
          <FilterBtn key={s} active={filter===s}
            color={s==="all"?C.brownMid:statusCol[s]||C.brownMid}
            onClick={()=>setFilter(s)}>
            {s.charAt(0).toUpperCase()+s.slice(1)}
          </FilterBtn>
        ))}
      </div>

      <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(270px,1fr))", gap:14, marginBottom:28 }}>
        {filtered.map(t=>{
          const col=statusCol[t.status]||C.textMuted;
          const bg=statusBg[t.status]||C.cardAlt;
          return (
            <Card key={t.id} style={{ padding:20 }}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:16 }}>
                <span style={{ fontFamily:F.mono, fontWeight:700, color:C.textH, fontSize:15 }}>{t.id}</span>
                <span style={{ background:bg, color:col, border:`1px solid ${col}44`,
                  borderRadius:5, padding:"3px 10px", fontSize:11, fontWeight:600,
                  fontFamily:F.body, textTransform:"capitalize" }}>{t.status}</span>
              </div>
              {[["Location",t.location],["Driver",t.driver],["Capacity",`${t.capacity.toLocaleString()} L`]].map(([k,v])=>(
                <div key={k} style={{ display:"flex", justifyContent:"space-between",
                  padding:"7px 0", borderBottom:`1px solid ${C.borderSoft}` }}>
                  <span style={{ fontFamily:F.body, color:C.textMuted, fontSize:12 }}>{k}</span>
                  <span style={{ fontFamily:F.body, color:C.textBody, fontSize:12, fontWeight:500 }}>{v}</span>
                </div>
              ))}
              {t.status==="available"&&(
                <button style={{ marginTop:14, width:"100%", padding:"9px",
                  background:C.blueBg, border:`1px solid ${C.blueLight}`,
                  borderRadius:6, color:C.blue, cursor:"pointer",
                  fontSize:12, fontWeight:600, fontFamily:F.body,
                  transition:"all 0.15s" }}>
                  Assign to Village →
                </button>
              )}
            </Card>
          );
        })}
      </div>

      <Card>
        <CardHead
          left={<div>
            <div style={{ fontFamily:F.heading, fontWeight:600, color:C.textH, fontSize:14 }}>Auto-Priority Allocation</div>
            <div style={{ fontFamily:F.body, color:C.textMuted, fontSize:12, marginTop:2 }}>Ranked by Stress Score × Population — highest need dispatched first</div>
          </div>}
        />
        <div style={{ padding:"14px 18px", display:"flex", flexDirection:"column", gap:8 }}>
          {priorityRank(VILLAGES,5).map((v,i)=>(
            <div key={v.id} style={{ display:"flex", alignItems:"center", gap:12,
              padding:"11px 16px", background:C.cardAlt,
              borderRadius:7, border:`1px solid ${C.border}` }}>
              <span style={{ fontFamily:F.mono, color:C.brownMid, fontSize:14,
                fontWeight:700, minWidth:28 }}>#{i+1}</span>
              <div style={{ flex:1 }}>
                <span style={{ fontFamily:F.body, color:C.textH, fontSize:13, fontWeight:600 }}>{v.name}</span>
                <span style={{ fontFamily:F.body, color:C.textMuted, fontSize:11, marginLeft:8 }}>{v.district}</span>
              </div>
              <Badge level={v.stress}/>
              <span style={{ fontFamily:F.mono, color:C.textMuted, fontSize:11 }}>Score {v.score}</span>
              <span style={{ fontFamily:F.mono, color:C.blueMid, fontSize:11 }}>{v.population.toLocaleString()}</span>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
function AlertsPage() {
  const [tf, setTf] = useState("all");
  const counts = {
    critical:ALERTS.filter(a=>a.type==="critical").length,
    high:ALERTS.filter(a=>a.type==="high").length,
    moderate:ALERTS.filter(a=>a.type==="moderate").length,
    normal:ALERTS.filter(a=>a.type==="normal").length
  };
  const filtered = tf==="all" ? ALERTS : ALERTS.filter(a=>a.type===tf);
  const tcol = { critical:C.critical, high:C.high, moderate:C.moderate, normal:C.normal };

  return (
    <div style={{ animation:"fadeIn 0.4s ease" }}>
      <PageTitle title="Alert Centre" sub="Water stress notifications & dispatch warnings" />

      <div style={{ display:"flex", gap:8, marginBottom:24, flexWrap:"wrap" }}>
        <FilterBtn active={tf==="all"} color={C.brownMid} onClick={()=>setTf("all")}>All ({ALERTS.length})</FilterBtn>
        {["critical","high","moderate","normal"].map(t=>(
          <FilterBtn key={t} active={tf===t} color={tcol[t]} onClick={()=>setTf(t)}>
            {t.charAt(0).toUpperCase()+t.slice(1)} ({counts[t]})
          </FilterBtn>
        ))}
      </div>

      <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
        {filtered.map((a,i)=>{
          const col=getStressColor(a.type.toUpperCase());
          const bg=getStressBg(a.type.toUpperCase());
          const bdr=getStressBorder(a.type.toUpperCase());
          return (
            <div key={a.id} style={{ background:bg,
              border:`1px solid ${bdr}`, borderLeft:`3px solid ${col}`,
              borderRadius:"0 8px 8px 0", padding:"14px 20px",
              display:"flex", alignItems:"center", gap:16,
              animation:`fadeSlideUp 0.35s ease ${i*0.04}s both`,
              boxShadow:"0 1px 3px rgba(0,0,0,0.04)" }}>
              <div style={{ width:7, height:7, borderRadius:"50%", background:col, flexShrink:0 }}/>
              <div style={{ flex:1 }}>
                <div style={{ fontFamily:F.body, color:C.textH, fontWeight:600,
                  fontSize:14, marginBottom:3 }}>{a.village}</div>
                <div style={{ fontFamily:F.body, color:C.textBody, fontSize:13 }}>{a.message}</div>
              </div>
              <div style={{ textAlign:"right", flexShrink:0 }}>
                <span style={{ background:C.card, color:col, border:`1px solid ${bdr}`,
                  borderRadius:4, padding:"3px 8px", fontSize:11, fontWeight:600,
                  display:"block", marginBottom:5, fontFamily:F.body }}>
                  {a.type.charAt(0).toUpperCase()+a.type.slice(1)}
                </span>
                <span style={{ fontFamily:F.body, color:C.textLight, fontSize:11 }}>{a.time}</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
function ReportsPage() {
  const vx = VILLAGES.map(v=>({...v, stress:getStressLevel(v.rainfall,v.groundwater), score:getScore(v.rainfall,v.groundwater)}));
  const totalPop  = VILLAGES.reduce((s,v)=>s+v.population,0);
  const critPop   = vx.filter(v=>v.stress==="CRITICAL").reduce((s,v)=>s+v.population,0);
  const avgRain   = Math.round(VILLAGES.reduce((s,v)=>s+v.rainfall,0)/VILLAGES.length);
  const avgGw     = Math.round(VILLAGES.reduce((s,v)=>s+v.groundwater,0)/VILLAGES.length);

  return (
    <div style={{ animation:"fadeIn 0.4s ease" }}>
      <PageTitle title="District Report" sub="Aggregated analysis — February 2026" />

      <div style={{ display:"flex", gap:14, marginBottom:26, flexWrap:"wrap" }}>
        <StatCard label="Total Population"   value={totalPop}  sub="Across 8 villages"                                  delay={0.0}/>
        <StatCard label="Population at Risk" value={critPop}   sub={`${Math.round(critPop/totalPop*100)}% of total`}    accent={C.critical}  delay={0.1}/>
        <StatCard label="Avg Rainfall"       value={avgRain}   sub="Monthly average"                                    accent={C.blueMid}   delay={0.2}/>
        <StatCard label="Avg Groundwater"    value={avgGw}     sub="Metres below surface"                               accent={C.moderate}  delay={0.3}/>
      </div>

      {/* Bar chart */}
      <Card style={{ marginBottom:22, padding:24 }}>
        <div style={{ marginBottom:20 }}>
          <h2 style={{ fontFamily:F.heading, fontSize:16, fontWeight:600, color:C.textH, margin:0 }}>Stress Score by Village</h2>
          <p style={{ fontFamily:F.body, color:C.textMuted, fontSize:12, margin:"4px 0 0" }}>Higher score = more severe drought stress</p>
        </div>
        <div style={{ display:"flex", gap:10, alignItems:"flex-end", height:160 }}>
          {vx.sort((a,b)=>b.score-a.score).map((v,i)=>{
            const col=getStressColor(v.stress);
            return (
              <div key={v.id} style={{ flex:1, display:"flex", flexDirection:"column", alignItems:"center", gap:5 }}>
                <span style={{ fontFamily:F.mono, color:C.textMuted, fontSize:9 }}>{v.score}</span>
                <div style={{ width:"100%", height:`${Math.max(v.score*1.4,4)}px`,
                  background:col+"cc", borderRadius:"4px 4px 0 0",
                  animation:`barGrow 0.7s ease ${i*0.08}s both` }}/>
                <span style={{ fontFamily:F.body, color:C.textMuted, fontSize:9,
                  textAlign:"center", lineHeight:1.4 }}>{v.name.split(" ")[0]}</span>
              </div>
            );
          })}
        </div>
        <div style={{ height:1, background:C.border, marginTop:2 }}/>
      </Card>

      <Card>
        <CardHead
          left={<span style={{ fontFamily:F.heading, fontWeight:600, color:C.textH, fontSize:14 }}>Complete Data Export</span>}
          right="8 villages · Feb 2026"
        />
        <div style={{ overflowX:"auto" }}>
          <table style={{ width:"100%", borderCollapse:"collapse" }}>
            <thead>
              <tr>{["Village","Rainfall","Groundwater","Score","Status","Tankers","Est. Daily Need"].map(h=><TH key={h}>{h}</TH>)}</tr>
            </thead>
            <tbody>
              {vx.sort((a,b)=>b.score-a.score).map((v,i)=>(
                <tr key={v.id} style={{ borderBottom:`1px solid ${C.borderSoft}`,
                  background:i%2===0?C.card:C.cardAlt }}>
                  <td style={{ padding:"11px 16px", fontFamily:F.body, color:C.textH, fontWeight:600, fontSize:13 }}>{v.name}</td>
                  <td style={{ padding:"11px 16px", fontFamily:F.mono, color:C.textBody, fontSize:12 }}>{v.rainfall} mm</td>
                  <td style={{ padding:"11px 16px", fontFamily:F.mono, color:C.textBody, fontSize:12 }}>{v.groundwater} m</td>
                  <td style={{ padding:"11px 16px", fontFamily:F.mono, color:C.textBody, fontSize:12 }}>{v.score}</td>
                  <td style={{ padding:"11px 16px" }}><Badge level={v.stress}/></td>
                  <td style={{ padding:"11px 16px", fontFamily:F.mono, color:C.blueMid, fontSize:12, fontWeight:600 }}>{v.tankerAssigned}</td>
                  <td style={{ padding:"11px 16px", fontFamily:F.mono, color:C.textBody, fontSize:12 }}>{(v.population*15).toLocaleString()} L</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
//  APP SHELL
// ═══════════════════════════════════════════════════════════════════════════════
const NAV = [
  { id:"dashboard", label:"Dashboard",  icon:"▣" },
  { id:"map",       label:"Stress Map", icon:"◎" },
  { id:"tankers",   label:"Tankers",    icon:"▤" },
  { id:"alerts",    label:"Alerts",     icon:"△" },
  { id:"reports",   label:"Reports",    icon:"▦" },
];

export default function App() {
  const [page, setPage] = useState("dashboard");
  const criticalCount = VILLAGES.filter(v=>getStressLevel(v.rainfall,v.groundwater)==="CRITICAL").length;
  const pages = { dashboard:<DashboardPage/>, map:<MapPage/>, tankers:<TankersPage/>, alerts:<AlertsPage/>, reports:<ReportsPage/> };

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Roboto+Mono:wght@400;500;600&display=swap');
        *, *::before, *::after { box-sizing:border-box; margin:0; padding:0; }
        html, body { height:100%; }
        body { background:${C.bgRoot}; font-family:'Inter','Segoe UI',system-ui,sans-serif; }
        ::-webkit-scrollbar { width:5px; height:5px; }
        ::-webkit-scrollbar-track { background:${C.bgRoot}; }
        ::-webkit-scrollbar-thumb { background:${C.border}; border-radius:3px; }
        ::-webkit-scrollbar-thumb:hover { background:${C.silverMid}; }
        button { outline:none; cursor:pointer; }
        tr:hover td { background:${C.silverPale}22 !important; }

        @keyframes fadeIn {
          from { opacity:0; } to { opacity:1; }
        }
        @keyframes fadeSlideUp {
          from { opacity:0; transform:translateY(10px); }
          to   { opacity:1; transform:translateY(0); }
        }
        @keyframes barGrow {
          from { transform:scaleY(0); transform-origin:bottom; }
          to   { transform:scaleY(1); transform-origin:bottom; }
        }
        @keyframes blink {
          0%,100% { opacity:1; }
          50%     { opacity:0.3; }
        }
      `}</style>

      <div style={{ display:"flex", minHeight:"100vh" }}>

        {/* ── Sidebar ── */}
        <aside style={{
          width:230, flexShrink:0,
          background: C.sidebar,
          padding:"24px 14px",
          display:"flex", flexDirection:"column", gap:3,
          position:"sticky", top:0, height:"100vh",
        }}>
          {/* Logo */}
          <div style={{ padding:"0 8px 26px" }}>
            <div style={{ display:"flex", alignItems:"center", gap:11 }}>
              <div style={{ width:38, height:38, borderRadius:9,
                background:`linear-gradient(135deg, ${C.blue}, ${C.greenMid})`,
                display:"flex", alignItems:"center", justifyContent:"center", fontSize:19 }}>💧</div>
              <div>
                <div style={{ fontFamily:F.heading, color:"#ffffff", fontWeight:700, fontSize:17, lineHeight:1 }}>AquaWatch</div>
                <div style={{ fontFamily:F.body, color:"rgba(255,255,255,0.4)", fontSize:9,
                  marginTop:4, letterSpacing:"0.1em" }}>DROUGHT COMMAND</div>
              </div>
            </div>
            <div style={{ height:1, background:"rgba(255,255,255,0.08)", marginTop:20 }}/>
          </div>

          {/* Nav items */}
          {NAV.map(item=>{
            const active=page===item.id;
            return (
              <button key={item.id} onClick={()=>setPage(item.id)} style={{
                display:"flex", alignItems:"center", gap:11,
                padding:"10px 12px", borderRadius:7,
                background: active ? "rgba(255,255,255,0.12)" : "transparent",
                border: `1px solid ${active?"rgba(255,255,255,0.18)":"transparent"}`,
                color: active ? "#ffffff" : "rgba(255,255,255,0.5)",
                cursor:"pointer", fontSize:13,
                fontWeight: active ? 600 : 400,
                fontFamily:F.body, textAlign:"left", width:"100%",
                transition:"all 0.15s",
              }}>
                <span style={{ fontSize:12, opacity:0.7 }}>{item.icon}</span>
                {item.label}
                {item.id==="alerts"&&criticalCount>0&&(
                  <span style={{ marginLeft:"auto", background:C.critical,
                    color:"#fff", borderRadius:"50%", width:18, height:18,
                    display:"flex", alignItems:"center", justifyContent:"center",
                    fontSize:10, fontWeight:700 }}>
                    {criticalCount}
                  </span>
                )}
              </button>
            );
          })}

          {/* Sidebar footer */}
          <div style={{ marginTop:"auto", padding:"16px 8px 0",
            borderTop:"1px solid rgba(255,255,255,0.08)" }}>
            {/* mini stress bar */}
            <div style={{ marginBottom:14 }}>
              <div style={{ fontFamily:F.body, color:"rgba(255,255,255,0.3)",
                fontSize:9, letterSpacing:"0.1em", marginBottom:6 }}>STRESS DISTRIBUTION</div>
              <div style={{ display:"flex", gap:2, height:4, borderRadius:2, overflow:"hidden" }}>
                {[{l:"CRITICAL",w:25},{l:"HIGH",w:37},{l:"MODERATE",w:25},{l:"NORMAL",w:13}].map(s=>(
                  <div key={s.l} style={{ width:`${s.w}%`, height:"100%", background:getStressColor(s.l) }}/>
                ))}
              </div>
            </div>
            <div style={{ fontFamily:F.body, color:"rgba(255,255,255,0.3)",
              fontSize:9, letterSpacing:"0.1em" }}>LAST SYNC</div>
            <div style={{ fontFamily:F.mono, color:"rgba(255,255,255,0.5)",
              fontSize:11, marginTop:3 }}>2 mins ago</div>
            <div style={{ display:"flex", gap:7, alignItems:"center", marginTop:10 }}>
              <div style={{ width:7, height:7, borderRadius:"50%",
                background:C.greenLight }}/>
              <span style={{ fontFamily:F.body, color:"rgba(255,255,255,0.5)", fontSize:11 }}>System Online</span>
            </div>
          </div>
        </aside>

        {/* ── Main Content ── */}
        <main style={{ flex:1, background:C.bgMain,
          padding:"28px 38px", overflowY:"auto", maxHeight:"100vh" }}>

          {/* Topbar */}
          <div style={{ display:"flex", justifyContent:"space-between",
            alignItems:"center", marginBottom:28,
            paddingBottom:18, borderBottom:`1px solid ${C.border}` }}>
            <div style={{ display:"flex", gap:10 }}>
              {criticalCount>0&&(
                <div style={{ background:C.criticalBg,
                  border:`1px solid ${C.criticalBorder}`,
                  borderRadius:7, padding:"6px 14px",
                  display:"flex", alignItems:"center", gap:8 }}>
                  <div style={{ width:6, height:6, borderRadius:"50%",
                    background:C.critical, animation:"blink 1.5s infinite" }}/>
                  <span style={{ fontFamily:F.body, color:C.critical,
                    fontSize:12, fontWeight:600 }}>
                    {criticalCount} Critical Villages
                  </span>
                </div>
              )}
            </div>
            <div style={{ fontFamily:F.mono, color:C.textLight, fontSize:11, letterSpacing:"0.04em" }}>
              Feb 23, 2026 · Maharashtra
            </div>
          </div>

          {pages[page]}
        </main>
      </div>
    </>
  );
}