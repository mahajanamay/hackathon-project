from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker, Session

DATABASE_URL = "postgresql://postgres:postgres123@localhost:5432/aquawatch"
engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(bind=engine)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
app = FastAPI(title="Drought & Tanker Management API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class Village(BaseModel):
    name: str
    rainfall_actual: float
    rainfall_normal: float
    groundwater_level: float
    population: int

def calculate_wsi(village, max_population):
    rainfall_deviation = (village.rainfall_normal - village.rainfall_actual) / village.rainfall_normal
    groundwater_decline = (100 - village.groundwater_level) / 100
    population_factor = village.population / max_population
    wsi = 0.4 * rainfall_deviation + 0.3 * groundwater_decline + 0.3 * population_factor
    return max(0, min(wsi, 1))

def stress_level(wsi):
    if wsi < 0.3:
        return "SAFE"
    elif wsi < 0.6:
        return "MODERATE"
    else:
        return "CRITICAL"

def tanker_prediction(village):
    daily_need = village.population * 135
    available_water = village.population * village.groundwater_level * 0.5
    deficit = max(daily_need - available_water, 0)
    tankers = deficit / 10000
    return round(tankers, 1)

@app.post("/analyze")
def analyze(villages: List[Village]):
    max_population = max(v.population for v in villages)
    results = []
    for v in villages:
        wsi = calculate_wsi(v, max_population)
        level = stress_level(wsi)
        tankers = tanker_prediction(v)
        population_factor = v.population / max_population
        priority = 0.7 * wsi + 0.3 * population_factor
        results.append({
            "village": v.name,
            "WSI": round(wsi, 2),
            "stress_level": level,
            "tankers_needed": tankers,
            "priority_score": round(priority, 2)
        })
    results.sort(key=lambda x: x["priority_score"], reverse=True)
    return {
        "analysis": results,
        "tanker_dispatch_order": [r["village"] for r in results]
    }

@app.get("/dashboard")
def dashboard():
    return {"message": "Dashboard running"}

@app.get("/routes")
def routes():
    return {"message": "Route optimization placeholder"}
class ReportInput(BaseModel):
    village: str
    district: str = ""
    reporter_name: str = ""
    issue_type: str
    severity: str
    description: str
    people_affected: int = 0
    since: str = ""

@app.post("/report")
def submit_report(report: ReportInput, db: Session = Depends(get_db)):
    db.execute(text("""
        INSERT INTO field_reports 
        (village, district, reporter_name, issue_type, severity, description, people_affected, since)
        VALUES (:village, :district, :reporter_name, :issue_type, :severity, :description, :people_affected, :since)
    """), report.dict())
    db.commit()
    return {"status": "saved"}

@app.get("/reports")
def get_reports(db: Session = Depends(get_db)):
    result = db.execute(text("SELECT * FROM field_reports ORDER BY submitted_at DESC")).fetchall()
    return [dict(r._mapping) for r in result]