import { GoogleMap, LoadScript, Marker, InfoWindow } from "@react-google-maps/api";
import { useState, useEffect } from "react";

// ─── Design Tokens — LIGHT THEME ─────────────────────────────────────────────
const C = {
  bgRoot:     "#f6f3ed",
  bgMain:     "#ffffff",
  sidebar:    "#7b441a",
  sidebarAlt: "#243222",
  card:       "#ffffff",
  cardBorder: "#e2ddd4",
  cardAlt:    "#f7f5f0",
  border:     "#ddd8cc",
  borderSoft: "#eae6de",
  brown:      "#7a5c2e",
  brownMid:   "#9a7440",
  brownLight: "#b89060",
  brownPale:  "#e8d8b8",
  silver:     "#6b7a84",
  silverMid:  "#8a9aa4",
  silverLight:"#b0bec8",
  silverPale: "#dce6ec",
  green:      "#2e5e3e",
  greenMid:   "#3d7a50",
  greenLight: "#5a9e6a",
  greenPale:  "#c8e8d0",
  greenBg:    "#eef6f0",
  blue:       "#1e5f74",
  blueMid:    "#2e7d9a",
  blueLight:  "#4a9ab8",
  bluePale:   "#cce4ee",
  blueBg:     "#edf5f9",
  critical:   "#c0392b",
  criticalBg: "#fdf0ee",
  criticalBorder:"#f5c0bb",
  high:       "#b05a0a",
  highBg:     "#fdf4ec",
  moderate:   "#8a7a10",
  moderateBg: "#fdfaec",
  normal:     "#2e6e40",
  normalBg:   "#eef6f1",
  textH:      "#000000",
  textBody:   "#3a4840",
  textMuted:  "#6a7870",
  textDim:    "#9aaaa0",
  textLight:  "#ffffff",
};

const F = {
  heading: "'Inter', 'Segoe UI', system-ui, sans-serif",
  body:    "'Inter', 'Segoe UI', system-ui, sans-serif",
  mono:    "'Roboto Mono', 'Courier New', monospace",
};

// ─── Data ─────────────────────────────────────────────────────────────────────
const VILLAGES = [
  { id:1, name:"Marathwada North", district:"Aurangabad", population:12400, lat:19.88, lng:75.34, rainfall:22,  groundwater:15, tankerAssigned:3 },
  { id:2, name:"Solapur Rural",    district:"Solapur",    population:8900,  lat:17.68, lng:75.90, rainfall:55,  groundwater:38, tankerAssigned:1 },
  { id:3, name:"Latur East",       district:"Latur",      population:15200, lat:18.40, lng:76.56, rainfall:18,  groundwater:12, tankerAssigned:5 },
  { id:4, name:"Osmanabad Block",  district:"Osmanabad",  population:6700,  lat:18.18, lng:76.04, rainfall:72,  groundwater:55, tankerAssigned:0 },
  { id:5, name:"Nanded West",      district:"Nanded",     population:11300, lat:19.15, lng:77.31, rainfall:45,  groundwater:30, tankerAssigned:2 },
  { id:6, name:"Beed Central",     district:"Beed",       population:9800,  lat:18.99, lng:75.76, rainfall:28,  groundwater:20, tankerAssigned:4 },
  { id:7, name:"Jalna Taluka",     district:"Jalna",      population:7200,  lat:19.84, lng:75.88, rainfall:85,  groundwater:68, tankerAssigned:0 },
  { id:8, name:"Hingoli Block",    district:"Hingoli",    population:5400,  lat:19.72, lng:77.15, rainfall:62,  groundwater:44, tankerAssigned:1 },
];
const TANKERS = [
  { id:"T-001", capacity:10000, status:"deployed",    location:"Marathwada North", driver:"Rajan More"     },
  { id:"T-002", capacity:8000,  status:"deployed",    location:"Latur East",       driver:"Suresh Patil"   },
  { id:"T-003", capacity:12000, status:"available",   location:"Depot A",          driver:"Manoj Kale"     },
  { id:"T-004", capacity:10000, status:"deployed",    location:"Beed Central",     driver:"Dinesh Jadhav"  },
  { id:"T-005", capacity:8000,  status:"maintenance", location:"Garage B",         driver:"Anil Shinde"    },
  { id:"T-006", capacity:15000, status:"available",   location:"Depot A",          driver:"Vijay Gaikwad"  },
  { id:"T-007", capacity:10000, status:"deployed",    location:"Nanded West",      driver:"Pramod Desai"   },
  { id:"T-008", capacity:8000,  status:"deployed",    location:"Solapur Rural",    driver:"Sachin Bhosale" },
];
const ALERTS = [
  { id:1, type:"critical", village:"Latur East",       message:"Groundwater below 12m — immediate tanker dispatch required", time:"10 mins ago" },
  { id:2, type:"critical", village:"Marathwada North", message:"Rainfall 78% below seasonal average",                        time:"25 mins ago" },
  { id:3, type:"high",     village:"Beed Central",     message:"Water Stress Index elevated to HIGH",                        time:"1 hr ago"    },
  { id:4, type:"high",     village:"Nanded West",      message:"Groundwater declining — monitor closely",                    time:"2 hrs ago"   },
  { id:5, type:"moderate", village:"Solapur Rural",    message:"Rainfall deficit of 45% this week",                         time:"3 hrs ago"   },
  { id:6, type:"moderate", village:"Hingoli Block",    message:"Seasonal rainfall 38% below average",                       time:"4 hrs ago"   },
  { id:7, type:"normal",   village:"Jalna Taluka",     message:"Groundwater stable — no action needed",                     time:"5 hrs ago"   },
  { id:8, type:"high",     village:"Osmanabad Block",  message:"Groundwater dropped 8m this month",                         time:"6 hrs ago"   },
];

// ─── Logic ────────────────────────────────────────────────────────────────────
const getStressLevel = (r, g) => {
  if (r < 30 && g < 20) return "CRITICAL";
  if (r < 60 && g < 40) return "HIGH";
  if (r < 80)           return "MODERATE";
  return "NORMAL";
};
const getStressColor = l => ({ CRITICAL: C.critical, HIGH: C.high, MODERATE: C.moderate, NORMAL: C.normal }[l] || C.normal);
const getStressBg    = l => ({ CRITICAL: C.criticalBg, HIGH: C.highBg, MODERATE: C.moderateBg, NORMAL: C.normalBg }[l] || C.normalBg);
const getStressBorder= l => ({ CRITICAL: C.criticalBorder, HIGH:"#f5d0a0", MODERATE:"#e8dca0", NORMAL:"#a8d8b4" }[l] || "#a8d8b4");
const getScore = (r, g) => Math.round((Math.max(0,100-r)*0.5)+(Math.max(0,100-g)*0.5));
const priorityRank = (villages, n) =>
  [...villages]
    .map(v=>({...v, stress:getStressLevel(v.rainfall,v.groundwater), score:getScore(v.rainfall,v.groundwater)}))
    .sort((a,b)=>(b.score+b.population*0.001)-(a.score+a.population*0.001))
    .slice(0,n);

// ─── Animated Counter ─────────────────────────────────────────────────────────
function AnimCounter({ target, duration=1000 }) {
  const [val, setVal] = useState(0);
  useEffect(() => {
    let start = 0;
    const step = target / (duration / 16);
    const timer = setInterval(() => {
      start += step;
      if (start >= target) { setVal(target); clearInterval(timer); }
      else setVal(Math.floor(start));
    }, 16);
    return () => clearInterval(timer);
  }, [target]);
  return <span>{val}</span>;
}

// ─── Shared Components ────────────────────────────────────────────────────────
const Badge = ({ level }) => {
  const col = getStressColor(level);
  const bg  = getStressBg(level);
  const bdr = getStressBorder(level);
  return (
    <span style={{ background:bg, color:col, border:`1px solid ${bdr}`, borderRadius:4,
      padding:"3px 10px", fontSize:11, fontWeight:600, fontFamily:F.body, letterSpacing:"0.04em" }}>
      {level}
    </span>
  );
};

const StatCard = ({ label, value, sub, accent, icon, delay=0 }) => (
  <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:10,
    padding:"20px 22px", flex:1, minWidth:130, borderTop:`3px solid ${accent||C.brownMid}`,
    boxShadow:"0 1px 4px rgba(0,0,0,0.06)", animation:`fadeSlideUp 0.5s ease ${delay}s both` }}>
    <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:10 }}>
      <span style={{ fontFamily:F.body, color:C.textMuted, fontSize:11, fontWeight:500,
        letterSpacing:"0.04em", textTransform:"uppercase" }}>{label}</span>
      {icon && <span style={{ fontSize:16, opacity:0.35 }}>{icon}</span>}
    </div>
    <div style={{ fontFamily:F.heading, color:accent||C.brownMid, fontSize:36, fontWeight:700, lineHeight:1, marginBottom:6 }}>
      <AnimCounter target={typeof value==='number'?value:parseInt(value)||0}/>
    </div>
    {sub && <div style={{ fontFamily:F.body, color:C.textMuted, fontSize:12 }}>{sub}</div>}
  </div>
);

const Card = ({ children, style={} }) => (
  <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:10,
    overflow:"hidden", boxShadow:"0 1px 4px rgba(0,0,0,0.06)", ...style }}>{children}</div>
);

const CardHead = ({ left, right }) => (
  <div style={{ padding:"14px 20px", borderBottom:`1px solid ${C.borderSoft}`,
    display:"flex", justifyContent:"space-between", alignItems:"center", background:C.cardAlt }}>
    <div>{left}</div>
    {right && <div style={{ fontFamily:F.body, color:C.textMuted, fontSize:11 }}>{right}</div>}
  </div>
);

const PageTitle = ({ title, sub }) => (
  <div style={{ marginBottom:28 }}>
    <h1 style={{ fontFamily:F.heading, fontSize:26, fontWeight:700, color:C.textH, margin:0, letterSpacing:"-0.02em" }}>{title}</h1>
    {sub && <p style={{ fontFamily:F.body, color:C.textMuted, fontSize:13, margin:"5px 0 0" }}>{sub}</p>}
  </div>
);

const TH = ({ children }) => (
  <th style={{ padding:"10px 16px", textAlign:"left", fontFamily:F.body, color:C.textMuted,
    fontSize:11, fontWeight:600, letterSpacing:"0.05em", textTransform:"uppercase",
    whiteSpace:"nowrap", background:C.cardAlt, borderBottom:`1px solid ${C.border}` }}>{children}</th>
);

const FilterBtn = ({ active, color, onClick, children }) => (
  <button onClick={onClick} style={{ padding:"6px 16px", borderRadius:6,
    border:`1px solid ${active?color:C.border}`, background:active?color+"14":C.card,
    color:active?color:C.textMuted, cursor:"pointer", fontSize:12,
    fontWeight:active?600:400, fontFamily:F.body, transition:"all 0.15s" }}>{children}</button>
);

// ═══════════════════════════════════════════════════════════════════════════════
//  PAGES
// ═══════════════════════════════════════════════════════════════════════════════

function DashboardPage({ backendData }) {
  const vx = VILLAGES.map(v=>({...v, stress:getStressLevel(v.rainfall,v.groundwater), score:getScore(v.rainfall,v.groundwater)}));
  const critical = vx.filter(v=>v.stress==="CRITICAL").length;
  const high     = vx.filter(v=>v.stress==="HIGH").length;
  const deployed = TANKERS.filter(t=>t.status==="deployed").length;
  const avail    = TANKERS.filter(t=>t.status==="available").length;

  return (
    <div style={{ animation:"fadeIn 0.4s ease" }}>
      <PageTitle title="District Overview" sub="Real-time drought stress monitoring & tanker allocation status" />

      {backendData && backendData.analyze && (
        <div style={{ background:C.blueBg, border:`1px solid ${C.bluePale}`,
          borderLeft:`4px solid ${C.blueMid}`, borderRadius:8, padding:"14px 20px",
          marginBottom:22, display:"flex", gap:32, flexWrap:"wrap", alignItems:"center" }}>
          <span style={{ fontFamily:F.body, color:C.blueMid, fontSize:12, fontWeight:600 }}>🔴 LIVE BACKEND DATA</span>
          <div>
            <span style={{ fontFamily:F.body, color:C.textMuted, fontSize:11 }}>Avg WSI </span>
            <span style={{ fontFamily:F.mono, color:C.blue, fontWeight:700, fontSize:14 }}>
              {(backendData.analyze.analysis.reduce((s,r)=>s+r.WSI,0)/backendData.analyze.analysis.length).toFixed(2)}
            </span>
          </div>
          <div>
            <span style={{ fontFamily:F.body, color:C.textMuted, fontSize:11 }}>Total Tankers Needed </span>
            <span style={{ fontFamily:F.mono, color:C.blue, fontWeight:700, fontSize:14 }}>
              {backendData.analyze.analysis.reduce((s,r)=>s+r.tankers_needed,0).toFixed(1)}
            </span>
          </div>
          <div>
            <span style={{ fontFamily:F.body, color:C.textMuted, fontSize:11 }}>Priority #1 </span>
            <span style={{ fontFamily:F.mono, color:C.blue, fontWeight:700, fontSize:13 }}>
              {backendData.analyze.tanker_dispatch_order[0]}
            </span>
          </div>
        </div>
      )}

      <div style={{ display:"flex", gap:14, marginBottom:26, flexWrap:"wrap" }}>
        <StatCard label="Critical Villages"  value={critical}  sub="Immediate action needed"       accent={C.critical}  icon="⚠"  delay={0.0}/>
        <StatCard label="High Stress"        value={high}      sub="Monitor closely"               accent={C.high}      icon="↑"  delay={0.1}/>
        <StatCard label="Tankers Deployed"   value={deployed}  sub={`of ${TANKERS.length} total`}  accent={C.greenMid}  icon="🚚" delay={0.2}/>
        <StatCard label="Available Tankers"  value={avail}     sub="Ready for dispatch"            accent={C.blueMid}   icon="◎"  delay={0.3}/>
      </div>

      <Card style={{ marginBottom:22 }}>
        <CardHead
          left={<span style={{ fontFamily:F.heading, fontWeight:600, color:C.textH, fontSize:14 }}>Village Stress Index</span>}
          right={`${VILLAGES.length} locations monitored`}
        />
        <div style={{ overflowX:"auto" }}>
          <table style={{ width:"100%", borderCollapse:"collapse" }}>
            <thead>
              <tr>{["Village","District","Population","Rainfall mm","Groundwater m","Stress Score","Status","Tankers"].map(h=><TH key={h}>{h}</TH>)}</tr>
            </thead>
            <tbody>
              {vx.sort((a,b)=>b.score-a.score).map((v,i)=>(
                <tr key={v.id} style={{ borderBottom:`1px solid ${C.borderSoft}`,
                  background:i%2===0?C.card:C.cardAlt, transition:"background 0.15s" }}>
                  <td style={{ padding:"12px 16px", fontFamily:F.body, color:C.textH, fontWeight:600, fontSize:13 }}>{v.name}</td>
                  <td style={{ padding:"12px 16px", fontFamily:F.body, color:C.textMuted, fontSize:13 }}>{v.district}</td>
                  <td style={{ padding:"12px 16px", fontFamily:F.mono, color:C.textBody, fontSize:12 }}>{v.population.toLocaleString()}</td>
                  <td style={{ padding:"12px 16px", fontFamily:F.mono, color:C.textBody, fontSize:12 }}>{v.rainfall}</td>
                  <td style={{ padding:"12px 16px", fontFamily:F.mono, color:C.textBody, fontSize:12 }}>{v.groundwater}</td>
                  <td style={{ padding:"12px 16px" }}>
                    <div style={{ display:"flex", alignItems:"center", gap:9 }}>
                      <div style={{ width:72, height:5, background:C.borderSoft, borderRadius:3, overflow:"hidden" }}>
                        <div style={{ width:`${v.score}%`, height:"100%", background:getStressColor(v.stress), borderRadius:3 }}/>
                      </div>
                      <span style={{ fontFamily:F.mono, color:C.textMuted, fontSize:11 }}>{v.score}</span>
                    </div>
                  </td>
                  <td style={{ padding:"12px 16px" }}><Badge level={v.stress}/></td>
                  <td style={{ padding:"12px 16px", fontFamily:F.mono, color:C.blueMid, fontSize:13, fontWeight:600 }}>{v.tankerAssigned}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <Card style={{ border:`1px solid ${C.criticalBorder}` }}>
        <CardHead
          left={
            <div style={{ display:"flex", alignItems:"center", gap:9 }}>
              <div style={{ width:7, height:7, borderRadius:"50%", background:C.critical, animation:"blink 1.5s infinite" }}/>
              <span style={{ fontFamily:F.heading, fontWeight:600, color:C.critical, fontSize:14 }}>Live Alerts</span>
            </div>
          }
          right="Auto-refreshing"
        />
        {ALERTS.slice(0,4).map(a=>{
          const col = getStressColor(a.type.toUpperCase());
          return (
            <div key={a.id} style={{ display:"flex", alignItems:"center", gap:14,
              padding:"12px 20px", borderBottom:`1px solid ${C.borderSoft}` }}>
              <div style={{ width:6, height:6, borderRadius:"50%", background:col, flexShrink:0 }}/>
              <span style={{ fontFamily:F.body, color:C.textBody, fontSize:13, flex:1 }}>
                <strong style={{ color:C.textH }}>{a.village}</strong> — {a.message}
              </span>
              <span style={{ fontFamily:F.body, color:C.textMuted, fontSize:11, whiteSpace:"nowrap" }}>{a.time}</span>
            </div>
          );
        })}
      </Card>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
function MapPage() {
  const vx = VILLAGES.map(v=>({...v, stress:getStressLevel(v.rainfall,v.groundwater), score:getScore(v.rainfall,v.groundwater)}));
  const [sel, setSel] = useState(null);
  const MAPS_KEY = import.meta.env.VITE_GOOGLE_MAPS_KEY;

  const mapStyles = [
    { featureType:"water", elementType:"geometry", stylers:[{color:"#a2daf2"}] },
    { featureType:"landscape", elementType:"geometry", stylers:[{color:"#f3efe6"}] },
    { featureType:"road", elementType:"geometry", stylers:[{color:"#ffffff"},{lightness:100}] },
    { featureType:"poi", stylers:[{visibility:"off"}] },
    { featureType:"administrative", elementType:"labels.text.fill", stylers:[{color:"#6a7870"}] },
  ];

  // Custom circle marker icon per stress level
  const getMarkerIcon = (stress) => {
    const colors = { CRITICAL:"#c0392b", HIGH:"#b05a0a", MODERATE:"#8a7a10", NORMAL:"#2e6e40" };
    const col = colors[stress] || colors.NORMAL;
    return {
      path: "M 0,0 m -10,0 a 10,10 0 1,0 20,0 a 10,10 0 1,0 -20,0",
      fillColor: col,
      fillOpacity: 0.9,
      strokeColor: "#ffffff",
      strokeWeight: 2,
      scale: stress === "CRITICAL" ? 1.4 : stress === "HIGH" ? 1.2 : 1,
    };
  };

  return (
    <div style={{ animation:"fadeIn 0.4s ease" }}>
      <PageTitle title="Stress Map" sub="Village-level water stress — live Google Maps view" />

      <div style={{ display:"flex", gap:18, marginBottom:18, flexWrap:"wrap" }}>
        {["CRITICAL","HIGH","MODERATE","NORMAL"].map(l=>(
          <div key={l} style={{ display:"flex", alignItems:"center", gap:7 }}>
            <div style={{ width:9, height:9, borderRadius:"50%", background:getStressColor(l) }}/>
            <span style={{ fontFamily:F.body, color:C.textMuted, fontSize:12 }}>{l}</span>
          </div>
        ))}
      </div>

      <div style={{ display:"flex", gap:18, flexWrap:"wrap" }}>
        {/* ── Google Map ── */}
        <Card style={{ flex:2, minWidth:300, overflow:"hidden", height:460 }}>
          {MAPS_KEY ? (
            <LoadScript googleMapsApiKey={MAPS_KEY}>
              <GoogleMap
                mapContainerStyle={{ width:"100%", height:"100%" }}
                center={{ lat:18.8, lng:76.2 }}
                zoom={7}
                options={{ styles:mapStyles, disableDefaultUI:false, zoomControl:true, mapTypeControl:false, streetViewControl:false }}
              >
                {vx.map(v=>(
                  <Marker
                    key={v.id}
                    position={{ lat:v.lat, lng:v.lng }}
                    icon={getMarkerIcon(v.stress)}
                    onClick={()=>setSel(sel?.id===v.id ? null : v)}
                    title={v.name}
                  />
                ))}
                {sel && (
                  <InfoWindow
                    position={{ lat:sel.lat, lng:sel.lng }}
                    onCloseClick={()=>setSel(null)}
                    options={{ pixelOffset: { width:0, height:-12 } }}
                  >
                    <div style={{ fontFamily:"Inter,sans-serif", minWidth:160, padding:"4px 2px" }}>
                      <div style={{ fontWeight:700, fontSize:14, color:"#1a2420", marginBottom:4 }}>{sel.name}</div>
                      <div style={{ fontSize:12, color:"#6a7870", marginBottom:6 }}>{sel.district} District</div>
                      {[
                        ["Population", sel.population.toLocaleString()],
                        ["Rainfall", `${sel.rainfall} mm`],
                        ["Groundwater", `${sel.groundwater} m`],
                        ["Stress Score", sel.score],
                        ["Tankers", sel.tankerAssigned],
                      ].map(([k,val])=>(
                        <div key={k} style={{ display:"flex", justifyContent:"space-between",
                          fontSize:12, padding:"3px 0", borderTop:"1px solid #eae6de" }}>
                          <span style={{ color:"#6a7870" }}>{k}</span>
                          <span style={{ fontWeight:600, color:"#1a2420" }}>{val}</span>
                        </div>
                      ))}
                      <div style={{ marginTop:8, textAlign:"center" }}>
                        <span style={{ background:getStressBg(sel.stress), color:getStressColor(sel.stress),
                          border:`1px solid ${getStressBorder(sel.stress)}`, borderRadius:4,
                          padding:"2px 10px", fontSize:11, fontWeight:600 }}>{sel.stress}</span>
                      </div>
                    </div>
                  </InfoWindow>
                )}
              </GoogleMap>
            </LoadScript>
          ) : (
            <div style={{ height:"100%", display:"flex", flexDirection:"column",
              alignItems:"center", justifyContent:"center", background:C.cardAlt, gap:10 }}>
              <div style={{ fontSize:32 }}>🗺️</div>
              <div style={{ fontFamily:F.heading, color:C.textH, fontSize:15, fontWeight:600 }}>
                Google Maps API Key Missing
              </div>
              <div style={{ fontFamily:F.body, color:C.textMuted, fontSize:12, textAlign:"center", maxWidth:300 }}>
                Add <code style={{ background:C.bgRoot, padding:"2px 6px", borderRadius:4 }}>VITE_GOOGLE_MAPS_KEY=your_key</code> to your <code style={{ background:C.bgRoot, padding:"2px 6px", borderRadius:4 }}>.env</code> file in the my-app folder and restart the dev server.
              </div>
            </div>
          )}
        </Card>

        {/* ── Side panel ── */}
        <div style={{ flex:1, minWidth:210, display:"flex", flexDirection:"column", gap:12 }}>
          {sel ? (
            <Card style={{ border:`1px solid ${getStressBorder(sel.stress)}`, padding:20 }}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:16 }}>
                <div>
                  <div style={{ fontFamily:F.heading, color:C.textH, fontWeight:700, fontSize:17 }}>{sel.name}</div>
                  <div style={{ fontFamily:F.body, color:C.textMuted, fontSize:12, marginTop:2 }}>{sel.district}</div>
                </div>
                <Badge level={sel.stress}/>
              </div>
              {[["Population",sel.population.toLocaleString()],["Rainfall",`${sel.rainfall} mm`],
                ["Groundwater",`${sel.groundwater} m`],["Stress Score",getScore(sel.rainfall,sel.groundwater)],
                ["Tankers Assigned",sel.tankerAssigned]].map(([k,v])=>(
                <div key={k} style={{ display:"flex", justifyContent:"space-between",
                  padding:"8px 0", borderBottom:`1px solid ${C.borderSoft}` }}>
                  <span style={{ fontFamily:F.body, color:C.textMuted, fontSize:12 }}>{k}</span>
                  <span style={{ fontFamily:F.mono, color:C.textH, fontSize:12, fontWeight:500 }}>{v}</span>
                </div>
              ))}
            </Card>
          ):(
            <Card style={{ padding:24, textAlign:"center" }}>
              <div style={{ fontSize:24, marginBottom:8 }}>📍</div>
              <div style={{ fontFamily:F.body, color:C.textMuted, fontSize:13 }}>Click a marker on the map</div>
              <div style={{ fontFamily:F.body, color:C.textMuted, fontSize:11, marginTop:4 }}>to view village details</div>
            </Card>
          )}
          {["CRITICAL","HIGH","MODERATE","NORMAL"].map(level=>{
            const count=vx.filter(v=>v.stress===level).length;
            const col=getStressColor(level);
            const bg=getStressBg(level);
            return (
              <div key={level} style={{ background:bg, border:`1px solid ${getStressBorder(level)}`,
                borderLeft:`3px solid ${col}`, borderRadius:8, padding:"10px 14px",
                display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                <span style={{ fontFamily:F.body, color:C.textBody, fontSize:12, fontWeight:500 }}>{level}</span>
                <span style={{ fontFamily:F.mono, color:col, fontWeight:700, fontSize:14 }}>{count}</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
function TankersPage() {
  const [filter, setFilter] = useState("all");
  const filtered = filter==="all" ? TANKERS : TANKERS.filter(t=>t.status===filter);
  const statusCol = { deployed:C.blueMid, available:C.greenMid, maintenance:C.high };
  const statusBg  = { deployed:C.blueBg,  available:C.greenBg,  maintenance:C.highBg };

  return (
    <div style={{ animation:"fadeIn 0.4s ease" }}>
      <PageTitle title="Tanker Fleet" sub="Monitor and manage all water tanker deployments" />

      <div style={{ display:"flex", gap:14, marginBottom:24, flexWrap:"wrap" }}>
        {[
          { label:"Total Fleet",  val:TANKERS.length,                                        color:C.brownMid },
          { label:"Deployed",     val:TANKERS.filter(t=>t.status==="deployed").length,    color:C.blueMid  },
          { label:"Available",    val:TANKERS.filter(t=>t.status==="available").length,   color:C.greenMid },
          { label:"Maintenance",  val:TANKERS.filter(t=>t.status==="maintenance").length, color:C.high     },
        ].map((s,i)=>(
          <div key={s.label} style={{ background:C.card, border:`1px solid ${C.border}`,
            borderTop:`3px solid ${s.color}`, borderRadius:10, padding:"18px 22px",
            flex:1, minWidth:110, boxShadow:"0 1px 4px rgba(0,0,0,0.05)",
            animation:`fadeSlideUp 0.4s ease ${i*0.08}s both` }}>
            <div style={{ fontFamily:F.body, color:C.textMuted, fontSize:11, fontWeight:500,
              textTransform:"uppercase", letterSpacing:"0.05em", marginBottom:8 }}>{s.label}</div>
            <div style={{ fontFamily:F.heading, color:s.color, fontSize:32, fontWeight:700 }}>
              <AnimCounter target={s.val}/>
            </div>
          </div>
        ))}
      </div>

      <div style={{ display:"flex", gap:8, marginBottom:20, flexWrap:"wrap" }}>
        {["all","deployed","available","maintenance"].map(s=>(
          <FilterBtn key={s} active={filter===s}
            color={s==="all"?C.brownMid:statusCol[s]||C.brownMid}
            onClick={()=>setFilter(s)}>
            {s.charAt(0).toUpperCase()+s.slice(1)}
          </FilterBtn>
        ))}
      </div>

      <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(270px,1fr))", gap:14, marginBottom:28 }}>
        {filtered.map(t=>{
          const col=statusCol[t.status]||C.textMuted;
          const bg=statusBg[t.status]||C.cardAlt;
          return (
            <Card key={t.id} style={{ padding:20 }}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:16 }}>
                <span style={{ fontFamily:F.mono, fontWeight:700, color:C.textH, fontSize:15 }}>{t.id}</span>
                <span style={{ background:bg, color:col, border:`1px solid ${col}44`,
                  borderRadius:5, padding:"3px 10px", fontSize:11, fontWeight:600,
                  fontFamily:F.body, textTransform:"capitalize" }}>{t.status}</span>
              </div>
              {[["Location",t.location],["Driver",t.driver],["Capacity",`${t.capacity.toLocaleString()} L`]].map(([k,v])=>(
                <div key={k} style={{ display:"flex", justifyContent:"space-between",
                  padding:"7px 0", borderBottom:`1px solid ${C.borderSoft}` }}>
                  <span style={{ fontFamily:F.body, color:C.textMuted, fontSize:12 }}>{k}</span>
                  <span style={{ fontFamily:F.body, color:C.textBody, fontSize:12, fontWeight:500 }}>{v}</span>
                </div>
              ))}
              {t.status==="available"&&(
                <button style={{ marginTop:14, width:"100%", padding:"9px",
                  background:C.blueBg, border:`1px solid ${C.blueLight}`,
                  borderRadius:6, color:C.blue, cursor:"pointer",
                  fontSize:12, fontWeight:600, fontFamily:F.body }}>
                  Assign to Village →
                </button>
              )}
            </Card>
          );
        })}
      </div>

      <Card>
        <CardHead left={<div>
          <div style={{ fontFamily:F.heading, fontWeight:600, color:C.textH, fontSize:14 }}>Auto-Priority Allocation</div>
          <div style={{ fontFamily:F.body, color:C.textMuted, fontSize:12, marginTop:2 }}>Ranked by Stress Score × Population</div>
        </div>}/>
        <div style={{ padding:"14px 18px", display:"flex", flexDirection:"column", gap:8 }}>
          {priorityRank(VILLAGES,5).map((v,i)=>(
            <div key={v.id} style={{ display:"flex", alignItems:"center", gap:12,
              padding:"11px 16px", background:C.cardAlt, borderRadius:7, border:`1px solid ${C.border}` }}>
              <span style={{ fontFamily:F.mono, color:C.brownMid, fontSize:14, fontWeight:700, minWidth:28 }}>#{i+1}</span>
              <div style={{ flex:1 }}>
                <span style={{ fontFamily:F.body, color:C.textH, fontSize:13, fontWeight:600 }}>{v.name}</span>
                <span style={{ fontFamily:F.body, color:C.textMuted, fontSize:11, marginLeft:8 }}>{v.district}</span>
              </div>
              <Badge level={v.stress}/>
              <span style={{ fontFamily:F.mono, color:C.textMuted, fontSize:11 }}>Score {v.score}</span>
              <span style={{ fontFamily:F.mono, color:C.blueMid, fontSize:11 }}>{v.population.toLocaleString()}</span>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
function AlertsPage() {
  const [tf, setTf] = useState("all");
  const counts = {
    critical:ALERTS.filter(a=>a.type==="critical").length,
    high:ALERTS.filter(a=>a.type==="high").length,
    moderate:ALERTS.filter(a=>a.type==="moderate").length,
    normal:ALERTS.filter(a=>a.type==="normal").length,
  };
  const filtered = tf==="all" ? ALERTS : ALERTS.filter(a=>a.type===tf);
  const tcol = { critical:C.critical, high:C.high, moderate:C.moderate, normal:C.normal };

  return (
    <div style={{ animation:"fadeIn 0.4s ease" }}>
      <PageTitle title="Alert Centre" sub="Water stress notifications & dispatch warnings" />
      <div style={{ display:"flex", gap:8, marginBottom:24, flexWrap:"wrap" }}>
        <FilterBtn active={tf==="all"} color={C.brownMid} onClick={()=>setTf("all")}>All ({ALERTS.length})</FilterBtn>
        {["critical","high","moderate","normal"].map(t=>(
          <FilterBtn key={t} active={tf===t} color={tcol[t]} onClick={()=>setTf(t)}>
            {t.charAt(0).toUpperCase()+t.slice(1)} ({counts[t]})
          </FilterBtn>
        ))}
      </div>
      <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
        {filtered.map((a,i)=>{
          const col=getStressColor(a.type.toUpperCase());
          const bg=getStressBg(a.type.toUpperCase());
          const bdr=getStressBorder(a.type.toUpperCase());
          return (
            <div key={a.id} style={{ background:bg, border:`1px solid ${bdr}`, borderLeft:`3px solid ${col}`,
              borderRadius:"0 8px 8px 0", padding:"14px 20px", display:"flex", alignItems:"center", gap:16,
              animation:`fadeSlideUp 0.35s ease ${i*0.04}s both`, boxShadow:"0 1px 3px rgba(0,0,0,0.04)" }}>
              <div style={{ width:7, height:7, borderRadius:"50%", background:col, flexShrink:0 }}/>
              <div style={{ flex:1 }}>
                <div style={{ fontFamily:F.body, color:C.textH, fontWeight:600, fontSize:14, marginBottom:3 }}>{a.village}</div>
                <div style={{ fontFamily:F.body, color:C.textBody, fontSize:13 }}>{a.message}</div>
              </div>
              <div style={{ textAlign:"right", flexShrink:0 }}>
                <span style={{ background:C.card, color:col, border:`1px solid ${bdr}`,
                  borderRadius:4, padding:"3px 8px", fontSize:11, fontWeight:600,
                  display:"block", marginBottom:5, fontFamily:F.body }}>
                  {a.type.charAt(0).toUpperCase()+a.type.slice(1)}
                </span>
                <span style={{ fontFamily:F.body, color:C.textMuted, fontSize:11 }}>{a.time}</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
function ReportsPage() {
  const vx = VILLAGES.map(v=>({...v, stress:getStressLevel(v.rainfall,v.groundwater), score:getScore(v.rainfall,v.groundwater)}));
  const totalPop = VILLAGES.reduce((s,v)=>s+v.population,0);
  const critPop  = vx.filter(v=>v.stress==="CRITICAL").reduce((s,v)=>s+v.population,0);
  const avgRain  = Math.round(VILLAGES.reduce((s,v)=>s+v.rainfall,0)/VILLAGES.length);
  const avgGw    = Math.round(VILLAGES.reduce((s,v)=>s+v.groundwater,0)/VILLAGES.length);

  return (
    <div style={{ animation:"fadeIn 0.4s ease" }}>
      <PageTitle title="District Report" sub="Aggregated analysis — February 2026" />
      <div style={{ display:"flex", gap:14, marginBottom:26, flexWrap:"wrap" }}>
        <StatCard label="Total Population"   value={totalPop} sub="Across 8 villages"                                delay={0.0}/>
        <StatCard label="Population at Risk" value={critPop}  sub={`${Math.round(critPop/totalPop*100)}% of total`} accent={C.critical} delay={0.1}/>
        <StatCard label="Avg Rainfall"       value={avgRain}  sub="Monthly average"                                 accent={C.blueMid}  delay={0.2}/>
        <StatCard label="Avg Groundwater"    value={avgGw}    sub="Metres below surface"                            accent={C.moderate} delay={0.3}/>
      </div>

      <Card style={{ marginBottom:22, padding:24 }}>
        <div style={{ marginBottom:20 }}>
          <h2 style={{ fontFamily:F.heading, fontSize:16, fontWeight:600, color:C.textH, margin:0 }}>Stress Score by Village</h2>
          <p style={{ fontFamily:F.body, color:C.textMuted, fontSize:12, margin:"4px 0 0" }}>Higher score = more severe drought stress</p>
        </div>
        <div style={{ display:"flex", gap:10, alignItems:"flex-end", height:160 }}>
          {vx.sort((a,b)=>b.score-a.score).map((v,i)=>{
            const col=getStressColor(v.stress);
            return (
              <div key={v.id} style={{ flex:1, display:"flex", flexDirection:"column", alignItems:"center", gap:5 }}>
                <span style={{ fontFamily:F.mono, color:C.textMuted, fontSize:9 }}>{v.score}</span>
                <div style={{ width:"100%", height:`${Math.max(v.score*1.4,4)}px`,
                  background:col+"cc", borderRadius:"4px 4px 0 0",
                  animation:`barGrow 0.7s ease ${i*0.08}s both` }}/>
                <span style={{ fontFamily:F.body, color:C.textMuted, fontSize:9, textAlign:"center", lineHeight:1.4 }}>{v.name.split(" ")[0]}</span>
              </div>
            );
          })}
        </div>
        <div style={{ height:1, background:C.border, marginTop:2 }}/>
      </Card>

      <Card>
        <CardHead left={<span style={{ fontFamily:F.heading, fontWeight:600, color:C.textH, fontSize:14 }}>Complete Data Export</span>} right="8 villages · Feb 2026"/>
        <div style={{ overflowX:"auto" }}>
          <table style={{ width:"100%", borderCollapse:"collapse" }}>
            <thead>
              <tr>{["Village","Rainfall","Groundwater","Score","Status","Tankers","Est. Daily Need"].map(h=><TH key={h}>{h}</TH>)}</tr>
            </thead>
            <tbody>
              {vx.sort((a,b)=>b.score-a.score).map((v,i)=>(
                <tr key={v.id} style={{ borderBottom:`1px solid ${C.borderSoft}`, background:i%2===0?C.card:C.cardAlt }}>
                  <td style={{ padding:"11px 16px", fontFamily:F.body, color:C.textH, fontWeight:600, fontSize:13 }}>{v.name}</td>
                  <td style={{ padding:"11px 16px", fontFamily:F.mono, color:C.textBody, fontSize:12 }}>{v.rainfall} mm</td>
                  <td style={{ padding:"11px 16px", fontFamily:F.mono, color:C.textBody, fontSize:12 }}>{v.groundwater} m</td>
                  <td style={{ padding:"11px 16px", fontFamily:F.mono, color:C.textBody, fontSize:12 }}>{v.score}</td>
                  <td style={{ padding:"11px 16px" }}><Badge level={v.stress}/></td>
                  <td style={{ padding:"11px 16px", fontFamily:F.mono, color:C.blueMid, fontSize:12, fontWeight:600 }}>{v.tankerAssigned}</td>
                  <td style={{ padding:"11px 16px", fontFamily:F.mono, color:C.textBody, fontSize:12 }}>{(v.population*15).toLocaleString()} L</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
function AboutPage() {
  const team = [
    { name:"Arjun Deshmukh", role:"Backend Engineer",   icon:"⚙️", desc:"FastAPI architecture & WSI algorithm design" },
    { name:"Priya Kulkarni", role:"Frontend Developer",  icon:"🎨", desc:"React dashboard & data visualisation" },
    { name:"Rahul Patil",    role:"Data Analyst",        icon:"📊", desc:"Groundwater & rainfall dataset curation" },
    { name:"Sneha Jadhav",   role:"Field Coordinator",   icon:"🌾", desc:"Village-level ground truth validation" },
  ];
  const objectives = [
    { icon:"💧", title:"Early Detection",       desc:"Identify drought stress before it becomes a crisis using real-time WSI scoring across all monitored villages." },
    { icon:"🚚", title:"Smart Tanker Dispatch",  desc:"AI-prioritised allocation ensures the most water-stressed, high-population villages receive relief first." },
    { icon:"📡", title:"Live Monitoring",        desc:"Continuous tracking of rainfall deviation, groundwater levels, and population demand." },
    { icon:"🛡️", title:"Disaster Prevention",   desc:"Acting on early WSI signals prevents humanitarian crises before they escalate into full-scale drought emergencies." },
    { icon:"📋", title:"Community Reporting",    desc:"Ground-level reports from residents feed into the system, ensuring no distress signal goes unnoticed." },
    { icon:"🤝", title:"Equitable Relief",       desc:"Data-driven allocation removes bias — every village is assessed on the same scientific criteria." },
  ];

  return (
    <div style={{ animation:"fadeIn 0.4s ease" }}>
      <PageTitle title="About AquaWatch" sub="Our mission, team & the technology behind drought relief" />

      <div style={{ background:`linear-gradient(135deg, ${C.blue}18, ${C.greenMid}14)`,
        border:`1px solid ${C.bluePale}`, borderRadius:12, padding:"28px 32px",
        marginBottom:28, position:"relative", overflow:"hidden" }}>
        <div style={{ position:"absolute", right:24, top:16, fontSize:64, opacity:0.06 }}>💧</div>
        <div style={{ fontFamily:F.heading, color:C.blue, fontSize:11, fontWeight:700,
          letterSpacing:"0.12em", textTransform:"uppercase", marginBottom:10 }}>OUR MISSION</div>
        <p style={{ fontFamily:F.body, color:C.textH, fontSize:18, fontWeight:600, lineHeight:1.6, maxWidth:680, margin:"0 0 12px" }}>
          To prevent water scarcity deaths in Maharashtra's drought-prone districts through real-time AI monitoring and intelligent tanker dispatch.
        </p>
        <p style={{ fontFamily:F.body, color:C.textMuted, fontSize:14, lineHeight:1.7, maxWidth:640, margin:0 }}>
          AquaWatch was built for the 76 lakh people living across Marathwada's most vulnerable talukas — where a single delayed tanker can mean the difference between survival and crisis.
        </p>
      </div>

      <div style={{ marginBottom:30 }}>
        <h2 style={{ fontFamily:F.heading, fontSize:17, fontWeight:700, color:C.textH, marginBottom:16 }}>Core Objectives</h2>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(280px,1fr))", gap:14 }}>
          {objectives.map((o,i)=>(
            <div key={o.title} style={{ background:C.card, border:`1px solid ${C.border}`,
              borderRadius:10, padding:"18px 20px", boxShadow:"0 1px 4px rgba(0,0,0,0.05)",
              animation:`fadeSlideUp 0.4s ease ${i*0.06}s both` }}>
              <div style={{ fontSize:22, marginBottom:10 }}>{o.icon}</div>
              <div style={{ fontFamily:F.heading, color:C.textH, fontWeight:600, fontSize:14, marginBottom:6 }}>{o.title}</div>
              <div style={{ fontFamily:F.body, color:C.textMuted, fontSize:12, lineHeight:1.65 }}>{o.desc}</div>
            </div>
          ))}
        </div>
      </div>

      <Card style={{ marginBottom:28 }}>
        <CardHead left={<span style={{ fontFamily:F.heading, fontWeight:600, color:C.textH, fontSize:14 }}>How the Water Stress Index (WSI) Works</span>}/>
        <div style={{ padding:"20px 24px" }}>
          <div style={{ display:"flex", gap:14, flexWrap:"wrap", marginBottom:14 }}>
            {[
              { label:"Rainfall Deviation", weight:"40%", color:C.blueMid,  formula:"(normal − actual) ÷ normal" },
              { label:"Groundwater Decline",weight:"30%", color:C.moderate, formula:"(100 − level) ÷ 100" },
              { label:"Population Factor",  weight:"30%", color:C.critical, formula:"population ÷ max_population" },
            ].map(f=>(
              <div key={f.label} style={{ flex:1, minWidth:180, background:C.cardAlt,
                borderRadius:8, padding:"14px 16px", border:`1px solid ${C.border}` }}>
                <div style={{ display:"flex", justifyContent:"space-between", marginBottom:8 }}>
                  <span style={{ fontFamily:F.body, color:C.textH, fontSize:12, fontWeight:600 }}>{f.label}</span>
                  <span style={{ fontFamily:F.mono, color:f.color, fontSize:13, fontWeight:700 }}>{f.weight}</span>
                </div>
                <div style={{ fontFamily:F.mono, color:f.color, fontSize:11,
                  background:f.color+"12", borderRadius:4, padding:"4px 8px" }}>{f.formula}</div>
              </div>
            ))}
          </div>
          <div style={{ padding:"10px 16px", background:C.greenBg, borderRadius:7, border:`1px solid ${C.greenPale}` }}>
            <span style={{ fontFamily:F.mono, color:C.green, fontSize:12, fontWeight:600 }}>
              WSI = 0.4 × rainfall_deviation + 0.3 × groundwater_decline + 0.3 × population_factor
            </span>
          </div>
        </div>
      </Card>

      <div>
        <h2 style={{ fontFamily:F.heading, fontSize:17, fontWeight:700, color:C.textH, marginBottom:16 }}>The Team</h2>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(220px,1fr))", gap:14 }}>
          {team.map((m,i)=>(
            <div key={m.name} style={{ background:C.card, border:`1px solid ${C.border}`,
              borderRadius:10, padding:"20px", boxShadow:"0 1px 4px rgba(0,0,0,0.05)",
              animation:`fadeSlideUp 0.4s ease ${i*0.07}s both`, textAlign:"center" }}>
              <div style={{ width:52, height:52, borderRadius:"50%",
                background:`linear-gradient(135deg, ${C.blueBg}, ${C.greenBg})`,
                display:"flex", alignItems:"center", justifyContent:"center",
                fontSize:22, margin:"0 auto 14px", border:`2px solid ${C.border}` }}>{m.icon}</div>
              <div style={{ fontFamily:F.heading, color:C.textH, fontWeight:700, fontSize:14, marginBottom:4 }}>{m.name}</div>
              <div style={{ fontFamily:F.body, color:C.blueMid, fontSize:11, fontWeight:600,
                marginBottom:8, textTransform:"uppercase", letterSpacing:"0.05em" }}>{m.role}</div>
              <div style={{ fontFamily:F.body, color:C.textMuted, fontSize:11, lineHeight:1.5 }}>{m.desc}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
function SubmitReportPage() {
  const [form, setForm] = useState({
    village:"", district:"", reporterName:"", reporterContact:"",
    issueType:"water_shortage", severity:"moderate", description:"",
    peopleAffected:"", since:"",
  });
  const [submitted, setSubmitted] = useState(false);
  const [reports, setReports] = useState([
    { id:1, village:"Latur East",       district:"Latur",      issueType:"water_shortage", severity:"critical", description:"Borewell completely dry, 400 families with no water for 3 days.", peopleAffected:1800, time:"2 hrs ago",  status:"acknowledged" },
    { id:2, village:"Marathwada North", district:"Aurangabad", issueType:"tanker_delay",   severity:"high",     description:"Assigned tanker T-001 has not arrived in 48 hours.", peopleAffected:600,  time:"5 hrs ago",  status:"under_review" },
    { id:3, village:"Beed Central",     district:"Beed",       issueType:"water_quality",  severity:"moderate", description:"Tanker water has unusual colour and smell — possible contamination.", peopleAffected:300, time:"1 day ago",  status:"pending" },
  ]);

  const sevColor   = { critical:C.critical, high:C.high, moderate:C.moderate, low:C.normal };
  const sevBg      = { critical:C.criticalBg, high:C.highBg, moderate:C.moderateBg, low:C.normalBg };
  const statusLabel= { acknowledged:"✅ Acknowledged", under_review:"🔍 Under Review", pending:"⏳ Pending", resolved:"✔ Resolved" };
  const issueLabels= { water_shortage:"Water Shortage", tanker_delay:"Tanker Delay", water_quality:"Water Quality", infrastructure:"Infrastructure", other:"Other" };

  const set = (k,v) => setForm(f=>({...f,[k]:v}));

  const handleSubmit = async () => {
    if (!form.village || !form.description) return;
    try {
      await fetch("http://localhost:8000/report", {
        method:"POST",
        headers:{ "Content-Type":"application/json" },
        body: JSON.stringify({
          village: form.village,
          district: form.district,
          reporter_name: form.reporterName,
          issue_type: form.issueType,
          severity: form.severity,
          description: form.description,
          people_affected: parseInt(form.peopleAffected)||0,
          since: form.since || null,
        }),
      });
      // Refresh from DB
      const res = await fetch("http://localhost:8000/reports");
      const data = await res.json();
      setReports(data.map(r=>({
        ...r,
        issueType: r.issue_type,
        peopleAffected: r.people_affected,
        time: new Date(r.submitted_at).toLocaleString(),
      })));
    // eslint-disable-next-line no-unused-vars
    } catch(_e) {
      // Fallback: add locally if backend offline
      setReports(r=>[{ id:r.length+1, ...form, issueType:form.issueType,
        peopleAffected:parseInt(form.peopleAffected)||0, time:"just now", status:"pending" }, ...r]);
    }
    setSubmitted(true);
    setTimeout(()=>{
      setSubmitted(false);
      setForm({ village:"", district:"", reporterName:"", reporterContact:"",
        issueType:"water_shortage", severity:"moderate", description:"", peopleAffected:"", since:"" });
    }, 3000);
  };

  const inputStyle = {
    width:"100%", padding:"10px 12px", borderRadius:7,
    border:`1px solid ${C.border}`, background:C.bgRoot,
    fontFamily:F.body, color:C.textH, fontSize:13,
    outline:"none", boxSizing:"border-box",
  };
  const labelStyle = { fontFamily:F.body, color:C.textMuted, fontSize:11,
    fontWeight:600, letterSpacing:"0.04em", textTransform:"uppercase",
    display:"block", marginBottom:5 };

  return (
    <div style={{ animation:"fadeIn 0.4s ease" }}>
      <PageTitle title="Submit a Field Report" sub="Report water crises, tanker delays, or quality issues directly to district command" />
      <div style={{ display:"flex", gap:22, flexWrap:"wrap", alignItems:"flex-start" }}>

        <div style={{ flex:"1 1 380px" }}>
          <Card style={{ padding:24, position:"relative" }}>
            {submitted && (
              <div style={{ position:"absolute", inset:0, borderRadius:10,
                background:"rgba(255,255,255,0.96)", display:"flex", flexDirection:"column",
                alignItems:"center", justifyContent:"center", zIndex:10, animation:"fadeIn 0.3s ease" }}>
                <div style={{ fontSize:48, marginBottom:14 }}>✅</div>
                <div style={{ fontFamily:F.heading, color:C.green, fontSize:18, fontWeight:700, marginBottom:6 }}>Report Submitted!</div>
                <div style={{ fontFamily:F.body, color:C.textMuted, fontSize:13 }}>District command has been notified.</div>
              </div>
            )}
            <h2 style={{ fontFamily:F.heading, fontSize:15, fontWeight:700, color:C.textH, marginBottom:20 }}>New Report</h2>

            <div style={{ display:"flex", gap:14, marginBottom:16 }}>
              <div style={{ flex:1 }}>
                <label style={labelStyle}>Village *</label>
                <input style={inputStyle} placeholder="e.g. Latur East" value={form.village} onChange={e=>set("village",e.target.value)}/>
              </div>
              <div style={{ flex:1 }}>
                <label style={labelStyle}>District</label>
                <input style={inputStyle} placeholder="e.g. Latur" value={form.district} onChange={e=>set("district",e.target.value)}/>
              </div>
            </div>

            <div style={{ display:"flex", gap:14, marginBottom:16 }}>
              <div style={{ flex:1 }}>
                <label style={labelStyle}>Your Name</label>
                <input style={inputStyle} placeholder="Reporter name" value={form.reporterName} onChange={e=>set("reporterName",e.target.value)}/>
              </div>
              <div style={{ flex:1 }}>
                <label style={labelStyle}>Contact</label>
                <input style={inputStyle} placeholder="Optional" value={form.reporterContact} onChange={e=>set("reporterContact",e.target.value)}/>
              </div>
            </div>

            <div style={{ display:"flex", gap:14, marginBottom:16 }}>
              <div style={{ flex:1 }}>
                <label style={labelStyle}>Issue Type *</label>
                <select style={inputStyle} value={form.issueType} onChange={e=>set("issueType",e.target.value)}>
                  <option value="water_shortage">Water Shortage</option>
                  <option value="tanker_delay">Tanker Delay</option>
                  <option value="water_quality">Water Quality Issue</option>
                  <option value="infrastructure">Infrastructure Damage</option>
                  <option value="other">Other</option>
                </select>
              </div>
              <div style={{ flex:1 }}>
                <label style={labelStyle}>Severity *</label>
                <select style={inputStyle} value={form.severity} onChange={e=>set("severity",e.target.value)}>
                  <option value="critical">🔴 Critical — Immediate danger</option>
                  <option value="high">🟠 High — Urgent action needed</option>
                  <option value="moderate">🟡 Moderate — Deteriorating</option>
                  <option value="low">🟢 Low — Monitoring required</option>
                </select>
              </div>
            </div>

            <div style={{ display:"flex", gap:14, marginBottom:16 }}>
              <div style={{ flex:1 }}>
                <label style={labelStyle}>People Affected</label>
                <input style={inputStyle} type="number" placeholder="Estimated count" value={form.peopleAffected} onChange={e=>set("peopleAffected",e.target.value)}/>
              </div>
              <div style={{ flex:1 }}>
                <label style={labelStyle}>Issue Started Since</label>
                <input style={inputStyle} type="date" value={form.since} onChange={e=>set("since",e.target.value)}/>
              </div>
            </div>

            <div style={{ marginBottom:20 }}>
              <label style={labelStyle}>Description *</label>
              <textarea style={{ ...inputStyle, height:90, resize:"vertical", lineHeight:1.6 }}
                placeholder="Describe the situation — what is happening, who is affected, what help is needed..."
                value={form.description} onChange={e=>set("description",e.target.value)}/>
            </div>

            <button onClick={handleSubmit} style={{
              width:"100%", padding:"12px",
              background: form.village && form.description ? C.blue : C.border,
              color: form.village && form.description ? "#fff" : C.textMuted,
              border:"none", borderRadius:8, fontFamily:F.heading, fontSize:14, fontWeight:600,
              cursor: form.village && form.description ? "pointer" : "default", transition:"all 0.2s" }}>
              🚨 Submit Report to District Command
            </button>
            <p style={{ fontFamily:F.body, color:C.textMuted, fontSize:11, textAlign:"center", marginTop:10 }}>
              Reports reviewed by district officials within 2 hours · Anonymous submissions accepted
            </p>
          </Card>
        </div>

        <div style={{ flex:"1 1 320px" }}>
          <h2 style={{ fontFamily:F.heading, fontSize:15, fontWeight:700, color:C.textH, marginBottom:14 }}>Recent Field Reports</h2>
          <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
            {reports.map((r,i)=>{
              const col = sevColor[r.severity]||C.textMuted;
              const bg  = sevBg[r.severity]||C.cardAlt;
              return (
                <div key={r.id} style={{ background:bg, border:`1px solid ${col}30`,
                  borderLeft:`3px solid ${col}`, borderRadius:"0 8px 8px 0", padding:"14px 16px",
                  animation:`fadeSlideUp 0.35s ease ${i*0.06}s both` }}>
                  <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:6 }}>
                    <div>
                      <span style={{ fontFamily:F.body, color:C.textH, fontWeight:700, fontSize:13 }}>{r.village}</span>
                      <span style={{ fontFamily:F.body, color:C.textMuted, fontSize:11, marginLeft:7 }}>{r.district}</span>
                    </div>
                    <span style={{ fontFamily:F.body, color:col, fontSize:10, fontWeight:600,
                      background:C.card, borderRadius:4, padding:"2px 8px",
                      border:`1px solid ${col}30`, textTransform:"uppercase", whiteSpace:"nowrap" }}>{r.severity}</span>
                  </div>
                  <div style={{ fontFamily:F.body, color:C.textMuted, fontSize:11, marginBottom:4, fontWeight:500 }}>
                    {issueLabels[r.issueType]||r.issueType}
                    {r.peopleAffected ? ` · ~${Number(r.peopleAffected).toLocaleString()} affected` : ""}
                  </div>
                  <div style={{ fontFamily:F.body, color:C.textBody, fontSize:12, lineHeight:1.55, marginBottom:8 }}>{r.description}</div>
                  <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                    <span style={{ fontFamily:F.body, color:C.textMuted, fontSize:10 }}>{r.time}</span>
                    <span style={{ fontFamily:F.body, color:C.textMuted, fontSize:10, fontWeight:500 }}>{statusLabel[r.status]||r.status}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
//  APP SHELL
// ═══════════════════════════════════════════════════════════════════════════════
const NAV = [
  { id:"dashboard",     label:"Dashboard",    icon:"▣" },
  { id:"map",           label:"Stress Map",   icon:"◎" },
  { id:"tankers",       label:"Tankers",      icon:"▤" },
  { id:"alerts",        label:"Alerts",       icon:"△" },
  { id:"reports",       label:"Reports",      icon:"▦" },
  { id:"submit-report", label:"Field Report", icon:"📋" },
  { id:"about",         label:"About Us",     icon:"ℹ" },
];

const API = "http://localhost:8000";

export default function App() {
  const [page, setPage] = useState("dashboard");
  const [backendData, setBackendData] = useState(null);
  const [backendStatus, setBackendStatus] = useState("loading");

  useEffect(() => {
    const payload = VILLAGES.map(v => ({
      name: v.name,
      rainfall_actual: v.rainfall,
      rainfall_normal: 800,
      groundwater_level: v.groundwater,
      population: v.population,
    }));
    Promise.all([
      fetch(`${API}/analyze`, { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(payload) }).then(r=>r.json()),
      fetch(`${API}/dashboard`).then(r=>r.json()),
      fetch(`${API}/routes`).then(r=>r.json()),
    ])
      .then(([analyze, dashboard]) => {
        setBackendData({ analyze, kpis:dashboard, routes:analyze.analysis });
        setBackendStatus("connected");
      })
      .catch(() => setBackendStatus("mock"));
  }, []);

  const criticalCount = VILLAGES.filter(v=>getStressLevel(v.rainfall,v.groundwater)==="CRITICAL").length;
  const pages = {
    dashboard:       <DashboardPage backendData={backendData}/>,
    map:             <MapPage/>,
    tankers:         <TankersPage/>,
    alerts:          <AlertsPage/>,
    reports:         <ReportsPage/>,
    "submit-report": <SubmitReportPage/>,
    about:           <AboutPage/>,
  };

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Roboto+Mono:wght@400;500;600&display=swap');
        *, *::before, *::after { box-sizing:border-box; margin:0; padding:0; }
        html, body { height:100%; }
        body { background:${C.bgRoot}; font-family:'Inter','Segoe UI',system-ui,sans-serif; }
        ::-webkit-scrollbar { width:5px; height:5px; }
        ::-webkit-scrollbar-track { background:${C.bgRoot}; }
        ::-webkit-scrollbar-thumb { background:${C.border}; border-radius:3px; }
        ::-webkit-scrollbar-thumb:hover { background:${C.silverMid}; }
        button { outline:none; cursor:pointer; }
        tr:hover td { background:${C.silverPale}22 !important; }
        @keyframes fadeIn { from{opacity:0} to{opacity:1} }
        @keyframes fadeSlideUp { from{opacity:0;transform:translateY(10px)} to{opacity:1;transform:translateY(0)} }
        @keyframes barGrow { from{transform:scaleY(0);transform-origin:bottom} to{transform:scaleY(1);transform-origin:bottom} }
        @keyframes blink { 0%,100%{opacity:1} 50%{opacity:0.3} }
      `}</style>

      <div style={{ display:"flex", minHeight:"100vh" }}>

        <aside style={{ width:230, flexShrink:0, background:C.sidebar, padding:"24px 14px",
          display:"flex", flexDirection:"column", gap:3, position:"sticky", top:0, height:"100vh" }}>
          <div style={{ padding:"0 8px 26px" }}>
            <div style={{ display:"flex", alignItems:"center", gap:11 }}>
              <div style={{ width:38, height:38, borderRadius:9,
                background:`linear-gradient(135deg, ${C.blue}, ${C.greenMid})`,
                display:"flex", alignItems:"center", justifyContent:"center", fontSize:19 }}>💧</div>
              <div>
                <div style={{ fontFamily:F.heading, color:"#ffffff", fontWeight:700, fontSize:17, lineHeight:1 }}>AquaWatch</div>
                <div style={{ fontFamily:F.body, color:"rgba(255,255,255,0.4)", fontSize:9, marginTop:4, letterSpacing:"0.1em" }}>DROUGHT COMMAND</div>
              </div>
            </div>
            <div style={{ height:1, background:"rgba(255,255,255,0.08)", marginTop:20 }}/>
          </div>

          {NAV.map(item=>{
            const active=page===item.id;
            return (
              <button key={item.id} onClick={()=>setPage(item.id)} style={{
                display:"flex", alignItems:"center", gap:11, padding:"10px 12px", borderRadius:7,
                background:active?"rgba(255,255,255,0.12)":"transparent",
                border:`1px solid ${active?"rgba(255,255,255,0.18)":"transparent"}`,
                color:active?"#ffffff":"rgba(255,255,255,0.5)",
                cursor:"pointer", fontSize:13, fontWeight:active?600:400,
                fontFamily:F.body, textAlign:"left", width:"100%", transition:"all 0.15s" }}>
                <span style={{ fontSize:12, opacity:0.7 }}>{item.icon}</span>
                {item.label}
                {item.id==="alerts"&&criticalCount>0&&(
                  <span style={{ marginLeft:"auto", background:C.critical, color:"#fff",
                    borderRadius:"50%", width:18, height:18, display:"flex",
                    alignItems:"center", justifyContent:"center", fontSize:10, fontWeight:700 }}>
                    {criticalCount}
                  </span>
                )}
              </button>
            );
          })}

          <div style={{ marginTop:"auto", padding:"16px 8px 0", borderTop:"1px solid rgba(255,255,255,0.08)" }}>
            <div style={{ marginBottom:14 }}>
              <div style={{ fontFamily:F.body, color:"rgba(255,255,255,0.3)", fontSize:9, letterSpacing:"0.1em", marginBottom:6 }}>STRESS DISTRIBUTION</div>
              <div style={{ display:"flex", gap:2, height:4, borderRadius:2, overflow:"hidden" }}>
                {[{l:"CRITICAL",w:25},{l:"HIGH",w:37},{l:"MODERATE",w:25},{l:"NORMAL",w:13}].map(s=>(
                  <div key={s.l} style={{ width:`${s.w}%`, height:"100%", background:getStressColor(s.l) }}/>
                ))}
              </div>
            </div>
            <div style={{ fontFamily:F.body, color:"rgba(255,255,255,0.3)", fontSize:9, letterSpacing:"0.1em" }}>LAST SYNC</div>
            <div style={{ fontFamily:F.mono, color:"rgba(255,255,255,0.5)", fontSize:11, marginTop:3 }}>2 mins ago</div>
            <div style={{ display:"flex", gap:7, alignItems:"center", marginTop:10 }}>
              <div style={{ width:7, height:7, borderRadius:"50%",
                background:backendStatus==="connected"?C.greenLight:backendStatus==="mock"?"#f0c040":"#aaaaaa" }}/>
              <span style={{ fontFamily:F.body, color:"rgba(255,255,255,0.5)", fontSize:11 }}>
                {backendStatus==="connected"?"Backend Connected":backendStatus==="mock"?"Using Mock Data":"Connecting…"}
              </span>
            </div>
          </div>
        </aside>

        <main style={{ flex:1, background:C.bgMain, padding:"28px 38px", overflowY:"auto", maxHeight:"100vh" }}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center",
            marginBottom:28, paddingBottom:18, borderBottom:`1px solid ${C.border}` }}>
            <div style={{ display:"flex", gap:10 }}>
              {criticalCount>0&&(
                <div style={{ background:C.criticalBg, border:`1px solid ${C.criticalBorder}`,
                  borderRadius:7, padding:"6px 14px", display:"flex", alignItems:"center", gap:8 }}>
                  <div style={{ width:6, height:6, borderRadius:"50%", background:C.critical, animation:"blink 1.5s infinite" }}/>
                  <span style={{ fontFamily:F.body, color:C.critical, fontSize:12, fontWeight:600 }}>
                    {criticalCount} Critical Villages
                  </span>
                </div>
              )}
            </div>
            <div style={{ fontFamily:F.mono, color:C.textMuted, fontSize:11, letterSpacing:"0.04em" }}>
              Feb 23, 2026 · Maharashtra
            </div>
          </div>
          {pages[page]}
        </main>
      </div>
    </>
  );
}